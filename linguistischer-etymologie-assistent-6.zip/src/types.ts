export interface ChatMessage {
  id: string;
  role: "user" | "model";
  text: string;
  timestamp: string;
  isStreaming?: boolean;
}

export interface AnalysisResult {
  words: Array<{
    word: string;
    lemma: string;
    origin: string;
    classification: string;
    originDetails: string;
    reason: string;
    observation: string;
    interpretation: string;
    reference?: string;
    lexemeForms?: string;
  }>;
}
