import { useState, useMemo, useEffect, useRef } from "react";
import { 
  LINGUISTIC_DATA, 
  DEFAULT_TEXT, 
  LINGUISTIC_REPORT_MD,
  WordEntry 
} from "./defaultData";
import { ChatMessage } from "./types";
import { 
  BookOpen, 
  Search, 
  LayoutDashboard, 
  Sliders, 
  Brain, 
  Compass, 
  HelpCircle, 
  Info, 
  MessageSquare, 
  Send, 
  Globe, 
  CheckCircle, 
  ChevronRight, 
  AlertCircle, 
  RefreshCw, 
  Eye, 
  Sparkles,
  BookMarked,
  ArrowRight,
  Database,
  Bot
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

export default function App() {
  // Navigation tabs
  const [activeTab, setActiveTab] = useState<"explorer" | "chat">("explorer");
  
  // Custom text vs pre-loaded default text
  const [useCustomText, setUseCustomText] = useState(true);
  const [customText, setCustomText] = useState("");
  const [isAnalyzingCustom, setIsAnalyzingCustom] = useState(false);
  const [analysisError, setAnalysisError] = useState<string | null>(null);
  
  // Dynamic list of active linguistic decorations
  const [activeWords, setActiveWords] = useState<WordEntry[]>([]);
  const [activeText, setActiveText] = useState<string>("");
  
  // Highlighting config
  const [highlightMode, setHighlightMode] = useState<"origin" | "classification" | "none">("origin");
  const [textSize, setTextSize] = useState<"normal" | "large" | "extra-large">("large");
  const [selectedWord, setSelectedWord] = useState<WordEntry | null>(null);

  // Search and filters for the dashboard table
  const [searchQuery, setSearchQuery] = useState("");
  const [classificationFilter, setClassificationFilter] = useState("all");
  const [originFilter, setOriginFilter] = useState("all");
  const [sortField, setSortField] = useState<"word" | "origin" | "classification">("word");
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("asc");

  // Chat interface states
  const [chatInput, setChatInput] = useState("");
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([
    {
      id: "init",
      role: "model",
      text: "Guten Tag! Ich bin Ety, Ihr persönlicher etymologischer und soziolinguistischer Assistent.\n\nIch kann beliebige Texte auf Entlehnungen (Lehn- und Fremdwörter), Fremdeinflüsse (Anglizismen, Gallizismen, Latinismen etc.) und sprachgeschichtliche Schichten hin analysieren. Sie können mir auch theoretische Fragen zur historischen Linguistik stellen. Wie kann ich Ihnen heute helfen?",
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }
  ]);
  const [isSendingMessage, setIsSendingMessage] = useState(false);
  const chatBottomRef = useRef<HTMLDivElement>(null);

  // Auto scroll chat to bottom
  useEffect(() => {
    chatBottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [chatMessages]);

  // Load sample corpus
  const handleLoadExample = () => {
    setUseCustomText(false);
    setActiveWords(LINGUISTIC_DATA);
    setActiveText(DEFAULT_TEXT);
    setCustomText(DEFAULT_TEXT);
    setAnalysisError(null);
    setSelectedWord(LINGUISTIC_DATA[0]);
  };

  // Reset to empty state on demand
  const handleResetToDefault = () => {
    setUseCustomText(true);
    setActiveWords([]);
    setActiveText("");
    setCustomText("");
    setAnalysisError(null);
    setSelectedWord(null);
  };

  // Run dynamic analysis on custom text
  const handleAnalyzeCustomText = async () => {
    if (!customText.trim()) return;
    setIsAnalyzingCustom(true);
    setAnalysisError(null);
    try {
      const response = await fetch("/api/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text: customText }),
      });
      
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || "Unerwarteter Fehler bei der linguistischen Analyse.");
      }
      
      if (data.words && Array.isArray(data.words)) {
        if (data.words.length === 0) {
          setAnalysisError("Der Text wurde gescannt, es konnten jedoch keine eindeutigen Fremd- oder Lehnwörter identifiziert werden.");
        } else {
          // Format the dynamic outcome to match WordEntry schema
          const formattedWords: WordEntry[] = data.words.map((w: any, idx: number) => ({
            id: `custom_${idx}_${w.word.toLowerCase().replace(/[^a-z]/g, "")}`,
            word: w.word,
            lemma: w.lemma || w.word,
            origin: w.origin || "Unbekannt",
            classification: w.classification || "Fremdwort",
            originDetails: w.originDetails || "Etymologische Herkunft wird berechnet.",
            reason: w.reason || "Klassifizierung begründet durch morphologische Kriterien.",
            observation: w.observation || "Linguistische Beobachtung ausstehend.",
            interpretation: w.interpretation || "Linguistische Interpretation ausstehend.",
            reference: w.reference || "Keine Referenzdaten verfügbar.",
            exampleSentence: `... ${w.word} ...`
          }));
          
          setActiveWords(formattedWords);
          setActiveText(customText);
          setUseCustomText(true);
          setSelectedWord(formattedWords[0]);
        }
      } else {
        throw new Error("Fehlerhaftes Antwortformat der linguistischen Engine.");
      }
    } catch (err: any) {
      console.error(err);
      setAnalysisError(err.message || "Verbindung zum Server fehlgeschlagen. Überprüfen Sie Ihren API-Key in den Geheimnissen.");
    } finally {
      setIsAnalyzingCustom(false);
    }
  };

  // Fetch response from chatbot
  const handleSendMessage = async () => {
    if (!chatInput.trim()) return;
    const userMsg: ChatMessage = {
      id: Math.random().toString(),
      role: "user",
      text: chatInput,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };
    
    setChatMessages(prev => [...prev, userMsg]);
    setChatInput("");
    setIsSendingMessage(true);

    try {
      const apiHistory = chatMessages.map(m => ({
        role: m.role,
        text: m.text
      }));

      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: userMsg.text,
          contextText: activeText,
          history: apiHistory
        })
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || "Kommunikationsfehler mit der linguistischen API.");
      }

      setChatMessages(prev => [...prev, {
        id: Math.random().toString(),
        role: "model",
        text: data.text,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      }]);
    } catch (err: any) {
      setChatMessages(prev => [...prev, {
        id: Math.random().toString(),
        role: "model",
        text: `⚠️ **Fehler bei der Anfrage:**\n\n${err.message || "Es konnte keine Antwort generiert werden. Vergewissern Sie sich, dass der GEMINI_API_KEY im Secrets-Panel von Google AI Studio hinterlegt ist."}`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      }]);
    } finally {
      setIsSendingMessage(false);
    }
  };

  // Break text into highlightable components using regex logic
  const textSpans = useMemo(() => {
    if (!activeText || !activeWords.length) {
      return [{ text: activeText }];
    }

    const escapeRegExp = (str: string) => str.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    const sortedWords = [...activeWords].sort((a, b) => b.word.length - a.word.length);
    
    // Pattern matches any of the exact words
    const pattern = sortedWords.map(w => `(${escapeRegExp(w.word)})`).join("|");
    const regex = new RegExp(pattern, "gi");
    
    const parts = activeText.split(regex);
    const spans: Array<{ text: string; wordData?: WordEntry }> = [];
    
    for (const part of parts) {
      if (!part) continue;
      
      const foundMatch = sortedWords.find(w => w.word.toLowerCase() === part.toLowerCase());
      if (foundMatch) {
        spans.push({ text: part, wordData: foundMatch });
      } else {
        spans.push({ text: part });
      }
    }
    
    return spans;
  }, [activeText, activeWords]);

  // Color mapping by Origin language
  const getOriginColor = (origin: string, isActive: boolean) => {
    switch (origin) {
      case "Englisch":
        return isActive 
          ? "bg-blue-100 border-b-2 border-blue-500 text-blue-900 font-medium" 
          : "bg-blue-50/70 text-blue-800 hover:bg-blue-100 border-b border-blue-300";
      case "Französisch":
        return isActive 
          ? "bg-red-100 border-b-2 border-red-500 text-red-900 font-medium" 
          : "bg-red-50/70 text-red-800 hover:bg-red-100 border-b border-red-300";
      case "Arabisch":
        return isActive 
          ? "bg-rose-100 border-b-2 border-rose-500 text-rose-900 font-medium" 
          : "bg-rose-50/70 text-rose-800 hover:bg-rose-100 border-b border-rose-300";
      case "Italienisch":
        return isActive 
          ? "bg-emerald-100 border-b-2 border-emerald-500 text-emerald-900 font-medium" 
          : "bg-emerald-50/70 text-emerald-800 hover:bg-emerald-100 border-b border-emerald-300";
      case "Latein":
        return isActive 
          ? "bg-amber-100 border-b-2 border-amber-500 text-amber-900 font-medium" 
          : "bg-amber-50/70 text-amber-800 hover:bg-amber-100 border-b border-amber-300";
      case "Griechisch/Mehrstufig":
        return isActive 
          ? "bg-indigo-100 border-b-2 border-indigo-500 text-indigo-900 font-medium" 
          : "bg-indigo-50/70 text-indigo-800 hover:bg-indigo-100 border-b border-indigo-300";
      case "Gemischt (Mischform)":
        return isActive 
          ? "bg-purple-100 border-b-2 border-purple-500 text-purple-900 font-medium" 
          : "bg-purple-50/70 text-purple-800 hover:bg-purple-100 border-b border-purple-300";
      default:
        return isActive 
          ? "bg-slate-200 border-b-2 border-slate-600 text-slate-900 font-medium" 
          : "bg-slate-100 text-slate-800 hover:bg-slate-200 border-b border-slate-300";
    }
  };

  // Color mapping by Loan classification
  const getClassificationColor = (classification: string, isActive: boolean) => {
    switch (classification) {
      case "Fremdwort":
        return isActive 
          ? "bg-orange-150 border-b-2 border-orange-600 text-orange-950 font-medium" 
          : "bg-orange-50 text-orange-800 hover:bg-orange-100 border-b border-orange-300";
      case "Lehnwort":
        return isActive 
          ? "bg-teal-150 border-b-2 border-teal-600 text-teal-950 font-medium" 
          : "bg-teal-50 text-teal-800 hover:bg-teal-100 border-b border-teal-300";
      case "Vollständig integriert":
        return isActive 
          ? "bg-cyan-150 border-b-2 border-cyan-600 text-cyan-950 font-medium" 
          : "bg-cyan-50 text-cyan-800 hover:bg-cyan-100 border-b border-cyan-300";
      case "Unsicher":
      default:
        return isActive 
          ? "bg-fuchsia-150 border-b-2 border-fuchsia-600 text-fuchsia-950 font-medium" 
          : "bg-fuchsia-50 text-fuchsia-800 hover:bg-fuchsia-100 border-b border-fuchsia-300";
    }
  };

  // Statistics calculation
  const stats = useMemo(() => {
    const total = activeWords.length;
    const langCounts: Record<string, number> = {};
    const classCounts: Record<string, number> = {};

    activeWords.forEach(w => {
      langCounts[w.origin] = (langCounts[w.origin] || 0) + 1;
      classCounts[w.classification] = (classCounts[w.classification] || 0) + 1;
    });

    return {
      total,
      langCounts,
      classCounts
    };
  }, [activeWords]);

  // Hierachical compilation summary for table output grouped by classification then language
  const statisticalSummary = useMemo(() => {
    const groups: Record<string, Record<string, WordEntry[]>> = {
      "Fremdwort": {},
      "Lehnwort": {},
      "Vollständig integriert": {},
      "Unsicher": {}
    };

    activeWords.forEach(w => {
      const cls = w.classification || "Unsicher";
      const org = w.origin || "Keltisch/Andere";
      if (!groups[cls]) groups[cls] = {};
      if (!groups[cls][org]) groups[cls][org] = [];
      groups[cls][org].push(w);
    });

    const summaryRows: {
      classification: string;
      origin: string;
      count: number;
      percentage: number;
      words: string[];
    }[] = [];

    const totalCount = activeWords.length || 1;

    Object.entries(groups).forEach(([cls, langMap]) => {
      Object.entries(langMap).forEach(([org, list]) => {
        if (list.length > 0) {
          summaryRows.push({
            classification: cls,
            origin: org,
            count: list.length,
            percentage: Math.round((list.length / totalCount) * 100),
            words: list.map(w => w.word)
          });
        }
      });
    });

    // Sort by classification first, then by language count or name
    return summaryRows.sort((a, b) => {
      const classCompare = a.classification.localeCompare(b.classification);
      if (classCompare !== 0) return classCompare;
      return a.origin.localeCompare(b.origin);
    });
  }, [activeWords]);

  // Filtering and sorting the main overview table
  const filteredWords = useMemo(() => {
    return activeWords
      .filter(w => {
        const matchesSearch = 
          w.word.toLowerCase().includes(searchQuery.toLowerCase()) ||
          w.lemma.toLowerCase().includes(searchQuery.toLowerCase()) ||
          w.originDetails.toLowerCase().includes(searchQuery.toLowerCase());
        const matchesClass = classificationFilter === "all" || w.classification === classificationFilter;
        const matchesOrigin = originFilter === "all" || w.origin === originFilter;
        return matchesSearch && matchesClass && matchesOrigin;
      })
      .sort((a, b) => {
        let fieldA = a[sortField].toLowerCase();
        let fieldB = b[sortField].toLowerCase();
        if (sortDirection === "asc") {
          return fieldA.localeCompare(fieldB);
        } else {
          return fieldB.localeCompare(fieldA);
        }
      });
  }, [activeWords, searchQuery, classificationFilter, originFilter, sortField, sortDirection]);

  const toggleSort = (field: "word" | "origin" | "classification") => {
    if (sortField === field) {
      setSortDirection(prev => prev === "asc" ? "desc" : "asc");
    } else {
      setSortField(field);
      setSortDirection("asc");
    }
  };

  return (
    <div className="min-h-screen bg-[#faf9f6] text-[#2c3e50] font-sans antialiased selection:bg-amber-100 selection:text-amber-900">
      
      {/* Upper academic header banner */}
      <header className="border-b border-slate-200 bg-white/85 sticky top-0 backdrop-blur-md z-40">
        <div className="max-w-7xl mx-auto px-4 py-4 sm:px-6 lg:px-8 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="bg-amber-500/10 text-amber-800 p-2.5 rounded-lg border border-amber-300">
              <Compass className="w-6 h-6 stroke-[1.5]" />
            </div>
            <div>
              <h1 className="text-xl md:text-2xl font-serif font-bold text-slate-900 tracking-tight flex items-center gap-2">
                EtymoScan
              </h1>
              <p className="text-xs md:text-sm text-slate-500 font-mono">
                Dein persönlicher Assistent für Etymologie und Sprachkontakt
              </p>
            </div>
          </div>

          {/* Tab Selection */}
          <nav className="flex space-x-1 bg-slate-100 p-1.5 rounded-xl border border-slate-200 w-full md:w-auto overflow-x-auto">
            <button
              onClick={() => setActiveTab("explorer")}
              className={`flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-medium rounded-lg transition-all whitespace-nowrap ${
                activeTab === "explorer"
                  ? "bg-white text-slate-900 shadow-xs border border-slate-200"
                  : "text-slate-600 hover:text-slate-950 hover:bg-slate-50/55"
              }`}
            >
              <Eye className="w-3.5 h-3.5" />
              Text-Explorer
            </button>
            <button
              onClick={() => setActiveTab("chat")}
              className={`flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-medium rounded-lg transition-all whitespace-nowrap ${
                activeTab === "chat"
                  ? "bg-white text-slate-900 shadow-xs border border-slate-200"
                  : "text-slate-600 hover:text-slate-950 hover:bg-slate-50/55"
              }`}
            >
              <MessageSquare className="w-3.5 h-3.5 text-amber-700" />
              Ety fragen
            </button>
          </nav>
        </div>
      </header>

      {/* Main Container */}
      <main className="max-w-7xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
        
        {/* Core application logic wrapper */}
        <div id="core-app-container">
          
          {/* TAB 1: INTERACTIVE TEXT EXPLORER */}
          {activeTab === "explorer" && (
            activeText === "" ? (
              <div className="max-w-3xl mx-auto space-y-8 animate-fadeIn w-full">
                <div className="bg-white rounded-3xl border border-slate-200 p-8 sm:p-12 shadow-xs relative overflow-hidden">
                  <div className="absolute top-0 right-0 p-8 opacity-[0.02] pointer-events-none">
                    <Globe className="w-64 h-64 text-slate-900" />
                  </div>
                  
                  <div className="text-center space-y-4 max-w-2xl mx-auto">
                    <div className="inline-block p-4 bg-amber-500/10 text-amber-700 rounded-2xl border border-amber-200/50">
                      <BookOpen className="w-8 h-8 stroke-[1.5]" />
                    </div>
                    <h2 className="text-3xl font-serif font-bold text-slate-950 tracking-tight leading-tight">
                      Etymologisches Sprach-Laboratorium
                    </h2>
                    <p className="text-sm text-slate-600 leading-relaxed">
                      Pflegen Sie die wissenschaftliche Untersuchung beliebiger deutscher Sätze. Unser linguistischer Scanner erfasst lateinische, griechische, französische, englische oder italienische Wurzeln, differenziert präzise zwischen Fremd- und Lehnwörtern und liefert Fachbelege aus seriösen Referenzquellen.
                    </p>
                  </div>

                  <div className="mt-8 pt-8 border-t border-slate-100 space-y-4">
                    <label className="block text-xs font-mono text-slate-400 uppercase tracking-wider">
                      Linguistischer Untersuchungs-Korpus (Geben Sie Ihren Text ein)
                    </label>
                    <textarea
                      placeholder="Geben Sie hier Ihren zu analysierenden deutschen Satz oder Textabschnitt ein..."
                      value={customText}
                      onChange={(e) => setCustomText(e.target.value)}
                      rows={6}
                      className="w-full text-base rounded-xl bg-slate-50 border border-slate-300 p-4 text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500 focus:bg-white transition-all font-sans leading-relaxed"
                    />

                    <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-2">
                      <button
                        onClick={handleLoadExample}
                        className="flex items-center justify-center gap-1.5 px-5 py-2.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl border border-slate-300 transition-all cursor-pointer w-full sm:w-auto"
                      >
                        <RefreshCw className="w-4 h-4 text-amber-700 font-bold" />
                        Linguistisches Standardbeispiel laden
                      </button>

                      <button
                        onClick={handleAnalyzeCustomText}
                        disabled={isAnalyzingCustom || !customText.trim()}
                        className="flex items-center justify-center gap-2 text-xs font-bold px-6 py-2.5 bg-slate-900 hover:bg-slate-850 active:bg-black text-white rounded-xl transition-all disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer w-full sm:w-auto shadow-sm"
                      >
                        {isAnalyzingCustom ? (
                          <>
                            <RefreshCw className="w-4 h-4 animate-spin" />
                            Analysiere etymologisch...
                          </>
                        ) : (
                          <>
                            <Sparkles className="w-4 h-4 text-amber-400" />
                            Text analysieren (Gemini-AI)
                          </>
                        )}
                      </button>
                    </div>

                    {/* Quick helper about categorization */}
                    <div className="pt-6 border-t border-dashed border-slate-200 grid grid-cols-1 md:grid-cols-2 gap-4 text-xs text-slate-500">
                      <div className="space-y-1">
                        <strong className="text-slate-800 font-serif block">Fremdwort vs. Lehnwort</strong>
                        <p className="leading-relaxed">
                          <strong>Fremdwörter</strong> bewahren Züge der Herkunftssprache (Aussprache, Schreibung, Endung). <strong>Lehnwörter</strong> sind vollständig an deutsche Sprachmuster (Grammatik, Lautung) angepasst.
                        </p>
                      </div>
                      <div className="space-y-1">
                        <strong className="text-slate-800 font-serif block">Wissenschaftlicher Anspruch</strong>
                        <p className="leading-relaxed">
                          Die Analyse trennt strikt zwischen systemischen Beobachtungen (Phonologie, Orthographie) und sozio-historischen Interpretationen der Entlehnungsmotive.
                        </p>
                      </div>
                    </div>

                    {/* Analysis Error Message Display */}
                    {analysisError && (
                      <div className="mt-4 bg-red-50 border border-red-200 p-4 rounded-xl flex items-start gap-3 text-xs text-red-800">
                        <AlertCircle className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
                        <div className="space-y-1">
                          <p className="font-semibold">Linguistischer Analyse-Fehler:</p>
                          <p className="text-red-700 leading-normal">{analysisError}</p>
                          <p className="text-[11px] text-slate-500">Vergewissern Sie sich, dass der API-Key in den AI Studio Secrets des Projekts hinterlegt ist.</p>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ) : (
              <>
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
              
              {/* Left Column: Controlling & Text Display */}
              <div className="lg:col-span-7 space-y-6">
                
                {/* Mode Selector Panel */}
                <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs">
                  <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                    <div className="space-y-1">
                      <h2 className="text-sm font-mono text-slate-400 uppercase tracking-widest">
                        Aktueller Workspace
                      </h2>
                      <div className="font-serif text-lg font-bold text-slate-950">
                        {useCustomText ? "Eigenes Laboratorium (Modus: Dynamisch)" : "Vorgegebener Text (Elfie Semotan)"}
                      </div>
                    </div>
                    
                    <div className="flex gap-2 w-full sm:w-auto">
                      {useCustomText ? (
                        <button
                          onClick={handleResetToDefault}
                          className="flex items-center justify-center gap-1.5 px-3.5 py-2 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg border border-slate-300 transition-all cursor-pointer w-full sm:w-auto"
                        >
                          <RefreshCw className="w-3.5 h-3.5" />
                          Standard laden
                        </button>
                      ) : null}
                    </div>
                  </div>

                  <hr className="my-4 border-slate-150" />

                  {/* Highlights and Sizes control bar */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    
                    {/* Highlight Toggles */}
                    <div className="space-y-2">
                      <label className="text-xs font-medium text-slate-600 flex items-center gap-1">
                        <Sliders className="w-3.5 h-3.5" /> Highlight-Modus:
                      </label>
                      <div className="flex bg-slate-100 p-1 rounded-lg border border-slate-200">
                        <button
                          onClick={() => setHighlightMode("origin")}
                          className={`flex-1 text-center py-1 text-[11px] font-medium rounded-md transition-all cursor-pointer ${
                            highlightMode === "origin"
                              ? "bg-white text-slate-950 shadow-xs border border-slate-150"
                              : "text-slate-600 hover:text-slate-900"
                          }`}
                        >
                          Nach Herkunft
                        </button>
                        <button
                          onClick={() => setHighlightMode("classification")}
                          className={`flex-1 text-center py-1 text-[11px] font-medium rounded-md transition-all cursor-pointer ${
                            highlightMode === "classification"
                              ? "bg-white text-slate-950 shadow-xs border border-slate-150"
                              : "text-slate-600 hover:text-slate-900"
                          }`}
                        >
                          Fremd/Lehnwort
                        </button>
                        <button
                          onClick={() => setHighlightMode("none")}
                          className={`flex-1 text-center py-1 text-[11px] font-medium rounded-md transition-all cursor-pointer ${
                            highlightMode === "none"
                              ? "bg-white text-slate-950 shadow-xs border border-slate-150"
                              : "text-slate-600 hover:text-slate-900"
                          }`}
                        >
                          Keiner
                        </button>
                      </div>
                    </div>

                    {/* Text Size Slider */}
                    <div className="space-y-2">
                      <label className="text-xs font-medium text-slate-600 flex items-center gap-1">
                        Textanzeige-Schriftgröße:
                      </label>
                      <div className="flex bg-slate-100 p-1 rounded-lg border border-slate-200">
                        <button
                          onClick={() => setTextSize("normal")}
                          className={`flex-1 text-center py-1 text-[11px] font-medium rounded-md transition-all cursor-pointer ${
                            textSize === "normal"
                              ? "bg-white text-slate-950 shadow-xs border border-slate-150"
                              : "text-slate-600 hover:text-slate-950"
                          }`}
                        >
                          Normal
                        </button>
                        <button
                          onClick={() => setTextSize("large")}
                          className={`flex-1 text-center py-1 text-[11px] font-medium rounded-md transition-all cursor-pointer ${
                            textSize === "large"
                              ? "bg-white text-slate-950 shadow-xs border border-slate-150"
                              : "text-slate-600 hover:text-slate-950"
                          }`}
                        >
                          Groß
                        </button>
                        <button
                          onClick={() => setTextSize("extra-large")}
                          className={`flex-1 text-center py-1 text-[11px] font-medium rounded-md transition-all cursor-pointer ${
                            textSize === "extra-large"
                              ? "bg-white text-slate-950 shadow-xs border border-slate-150"
                              : "text-slate-600 hover:text-slate-950"
                          }`}
                        >
                          Sehr Groß
                        </button>
                      </div>
                    </div>

                  </div>
                </div>

                {/* TEXT CONTAINER / DOCUMENT DISPLAY */}
                <div className="bg-white rounded-2xl border border-slate-200 p-8 shadow-xs relative overflow-hidden">
                  
                  {/* Decorative book corner */}
                  <div className="absolute top-0 right-0 w-16 h-16 bg-[#faf9f6] border-b border-l border-slate-200 transform rotate-45 translate-x-8 -translate-y-8 pointer-events-none" />
                  
                  {/* Text metadata */}
                  <div className="flex items-center justify-between mb-6 text-xs text-slate-400 font-mono tracking-wider border-b border-dashed border-slate-150 pb-3">
                    <span className="flex items-center gap-1 uppercase">
                      <BookMarked className="w-3 h-3 text-amber-600" /> Analysiertes Korpus
                    </span>
                    <span>{activeText.split(/\s+/).length} Wörter • {activeWords.length} Sprachkontakte</span>
                  </div>

                  {/* Rendering Content */}
                  <div 
                    className={`font-serif tracking-wide leading-relaxed text-slate-800 ${
                      textSize === "normal" ? "text-base" : textSize === "large" ? "text-lg md:text-xl" : "text-xl md:text-2xl"
                    }`}
                  >
                    {textSpans.map((span, index) => {
                      if (span.wordData) {
                        const wordInfo = span.wordData;
                        const isSelected = selectedWord?.id === wordInfo.id;
                        
                        let highlightClass = "";
                        if (highlightMode === "origin") {
                          highlightClass = getOriginColor(wordInfo.origin, isSelected);
                        } else if (highlightMode === "classification") {
                          highlightClass = getClassificationColor(wordInfo.classification, isSelected);
                        } else {
                          highlightClass = isSelected 
                            ? "border-b-2 border-slate-700 font-medium bg-slate-150 text-slate-950" 
                            : "border-b border-dashed border-slate-400 hover:bg-slate-50";
                        }
                        
                        return (
                          <span
                            key={index}
                            onClick={() => setSelectedWord(wordInfo)}
                            className={`highlight-word inline-block px-1.5 py-0.5 rounded-sm mx-0.5 transition-all outline-none ${highlightClass}`}
                            title={`Herkunft: ${wordInfo.origin} (${wordInfo.classification})`}
                            role="button"
                            tabIndex={0}
                          >
                            {span.text}
                          </span>
                        );
                      }
                      
                      // Handle newline displays elegantly
                      if (span.text === "\n\n") {
                        return <span key={index} className="block my-6" />;
                      }
                      
                      return <span key={index}>{span.text}</span>;
                    })}
                  </div>

                  {/* Legend guide display */}
                  {highlightMode !== "none" && (
                    <div className="mt-8 pt-4 border-t border-slate-100 flex flex-wrap gap-2.5 items-center justify-start text-[11px] font-mono">
                      <span className="text-slate-400 uppercase tracking-widest mr-1">Legende:</span>
                      {highlightMode === "origin" ? (
                        <>
                          <span className="flex items-center gap-1.5 px-2 py-0.5 rounded bg-blue-50 text-blue-700 border border-blue-200">
                            <span className="w-2 h-2 rounded bg-blue-500" /> Englisch
                          </span>
                          <span className="flex items-center gap-1.5 px-2 py-0.5 rounded bg-red-50 text-red-700 border border-red-200">
                            <span className="w-2 h-2 rounded bg-red-500" /> Französisch
                          </span>
                          <span className="flex items-center gap-1.5 px-2 py-0.5 rounded bg-amber-50 text-amber-700 border border-amber-200">
                            <span className="w-2 h-2 rounded bg-amber-500" /> Latein
                          </span>
                          <span className="flex items-center gap-1.5 px-2 py-0.5 rounded bg-indigo-50 text-indigo-700 border border-indigo-200">
                            <span className="w-2 h-2 rounded bg-indigo-500" /> Griechisch/Mehrstufig
                          </span>
                          <span className="flex items-center gap-1.5 px-2 py-0.5 rounded bg-purple-50 text-purple-700 border border-purple-200">
                            <span className="w-2 h-2 rounded bg-purple-500" /> Gemischt (Mischform)
                          </span>
                        </>
                      ) : (
                        <>
                          <span className="flex items-center gap-1.5 px-2 py-0.5 rounded bg-orange-50 text-orange-700 border border-orange-200">
                            <span className="w-2 h-2 rounded bg-orange-500" /> Fremdwort
                          </span>
                          <span className="flex items-center gap-1.5 px-2 py-0.5 rounded bg-teal-50 text-teal-700 border border-teal-200">
                            <span className="w-2 h-2 rounded bg-teal-500" /> Lehnwort
                          </span>
                          <span className="flex items-center gap-1.5 px-2 py-0.5 rounded bg-cyan-50 text-cyan-700 border border-cyan-200">
                            <span className="w-2 h-2 rounded bg-cyan-500" /> Vollständig integriert
                          </span>
                          <span className="flex items-center gap-1.5 px-2 py-0.5 rounded bg-fuchsia-50 text-fuchsia-700 border border-fuchsia-200">
                            <span className="w-2 h-2 rounded bg-fuchsia-500" /> Unsicher/Grenzfall
                          </span>
                        </>
                      )}
                    </div>
                  )}
                </div>

                {/* DYNAMIC TEXT LABORATORY DRAWER */}
                <div className="bg-slate-900 text-slate-150 rounded-2xl p-6 border border-slate-850 shadow-lg relative overflow-hidden">
                  <div className="absolute top-0 right-0 p-4 opacity-5 pointer-events-none">
                    <Brain className="w-32 h-32 text-white" />
                  </div>
                  
                  <div className="flex items-start gap-3">
                    <div className="bg-amber-500/25 p-2 rounded-lg text-amber-400 border border-amber-500/30">
                      <Sparkles className="w-5 h-5" />
                    </div>
                    <div className="space-y-1">
                      <h3 className="text-base font-serif font-bold text-white flex items-center gap-2">
                        Etymologisches Laboratorium (AI-gesteuert)
                      </h3>
                      <p className="text-xs text-slate-400 leading-normal max-w-lg">
                        Geben Sie einen beliebigen eigenen Satz ein. Die künstliche linguistische Intelligenz spürt Fremd- und Lehnwörter selbstständig auf und liefert ein vollständiges Dossier.
                      </p>
                    </div>
                  </div>

                  <div className="mt-4 space-y-3">
                    <textarea
                      placeholder="Geben Sie hier einen eigenen Satz zur Analyse ein..."
                      value={customText}
                      onChange={(e) => setCustomText(e.target.value)}
                      rows={3}
                      className="w-full text-sm rounded-lg bg-slate-950 border border-slate-800 p-3 text-slate-200 placeholder-slate-600 focus:outline-none focus:ring-1 focus:ring-amber-500"
                    />
                    
                    <div className="flex flex-wrap items-center justify-between gap-3">
                      <div className="font-mono text-[10px] text-slate-500">
                        {customText.length} Zeichen • Benötigt Gemini API Key
                      </div>
                      
                      <div className="flex gap-2">
                        {useCustomText && (
                          <button
                            onClick={handleResetToDefault}
                            className="text-xs font-medium px-4 py-2 bg-slate-800 text-slate-300 hover:bg-slate-700 hover:text-white rounded-lg transition-all cursor-pointer"
                          >
                            Zurücksetzen
                          </button>
                        )}
                        <button
                          onClick={handleAnalyzeCustomText}
                          disabled={isAnalyzingCustom || !customText.trim()}
                          className="flex items-center gap-1.5 text-xs font-semibold px-4 py-2 bg-amber-500 hover:bg-amber-400 active:bg-amber-600 text-slate-950 rounded-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
                        >
                          {isAnalyzingCustom ? (
                            <>
                              <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                              Analysiere linguistisch...
                            </>
                          ) : (
                            <>
                              <Database className="w-3.5 h-3.5" />
                              Eigene Sätze scannen
                            </>
                          )}
                        </button>
                      </div>
                    </div>

                    {/* Analysis Error Message Display */}
                    {analysisError && (
                      <div className="mt-3 bg-red-950/40 border border-red-900/40 p-3 rounded-lg flex items-start gap-2.5 text-xs text-red-200">
                        <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
                        <div className="space-y-1">
                          <p className="font-semibold">Linguistischer Engine-Hinweis:</p>
                          <p className="text-slate-300 leading-normal">{analysisError}</p>
                          <p className="text-[10px] text-slate-400">Vergewissern Sie sich, dass der API-Key in den AI Studio Secrets gesetzt wurde.</p>
                        </div>
                      </div>
                    )}
                  </div>
                </div>

              </div>

              {/* Right Column: Etymological Word Dossier */}
              <div className="lg:col-span-5 lg:sticky lg:top-24">
                <AnimatePresence mode="wait">
                  {selectedWord ? (
                    <motion.div
                      key={selectedWord.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -10 }}
                      transition={{ duration: 0.18 }}
                      className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden"
                    >
                      {/* Top Accent Header */}
                      <div className="p-6 bg-slate-900 text-white relative">
                        <div className="flex items-start justify-between">
                          <div className="space-y-1.5">
                            <span className="inline-block text-[10px] font-mono uppercase tracking-widest text-amber-400">
                              Etymologischer Steckbrief
                            </span>
                            <h3 className="text-2xl md:text-3xl font-serif font-bold tracking-tight text-white">
                              {selectedWord.word}
                            </h3>
                          </div>
                          
                          {/* Badge Origin Language */}
                          <div className="flex flex-col items-end gap-1.5">
                            <span className="flex items-center gap-1 text-xs font-mono text-slate-300">
                              <Globe className="w-3 h-3 text-emerald-400" /> {selectedWord.origin}
                            </span>
                            <span className={`inline-block text-[11px] font-semibold px-2 py-0.5 rounded-full ${
                              selectedWord.classification === "Fremdwort" 
                                ? "bg-orange-600/20 border border-orange-500/35 text-orange-200"
                                : selectedWord.classification === "Lehnwort"
                                ? "bg-teal-600/20 border border-teal-500/35 text-teal-200"
                                : "bg-cyan-600/20 border border-cyan-500/35 text-cyan-200"
                            }`}>
                              {selectedWord.classification}
                            </span>
                          </div>
                        </div>

                        {/* Lemma line */}
                        <div className="mt-4 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs font-mono text-slate-400 border-t border-slate-800 pt-3">
                          <span>Grundform (Lemma): <strong>{selectedWord.lemma}</strong></span>
                        </div>
                      </div>

                      {/* Content Section */}
                      <div className="p-6 space-y-6">
                        
                        {/* 1. Etymologischer Stammbaum */}
                        <div className="space-y-2">
                          <h4 className="text-xs font-mono text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                            <ChevronRight className="w-3.5 h-3.5 text-slate-400" /> Etymologischer Stammbaum & Migration
                          </h4>
                          <p className="text-sm text-slate-700 leading-relaxed bg-[#fafaf8] p-3.5 rounded-lg border border-slate-150">
                            {selectedWord.originDetails}
                          </p>
                        </div>

                         {/* 2. Begründung der Klassifizierung */}
                        <div className="space-y-2">
                          <h4 className="text-xs font-mono text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                            <ChevronRight className="w-3.5 h-3.5 text-slate-400" /> Begründung der Klassifizierung
                          </h4>
                          <p className="text-sm text-slate-700 leading-relaxed border-l-3 border-amber-500 pl-3.5 py-1 font-sans">
                            {selectedWord.reason}
                          </p>
                        </div>

                        {/* 2b. Lexem-Variationen / Wortklassen */}
                        {selectedWord.lexemeForms && (
                          <div className="space-y-2 bg-amber-50/40 p-3.5 rounded-lg border border-amber-250/50">
                            <h4 className="text-xs font-mono text-amber-850 uppercase tracking-wider flex items-center gap-1.5 font-semibold">
                              <RefreshCw className="w-3.5 h-3.5 text-amber-600" /> Lexem-Variationen &amp; Wortklassen
                            </h4>
                            <p className="text-xs text-amber-900 leading-relaxed font-sans font-medium">
                              {selectedWord.lexemeForms}
                            </p>
                          </div>
                        )}

                        {/* 3. Objective Observation vs Sociolinguistic Interpretation */}
                        <div className="grid grid-cols-1 gap-4 pt-1">
                          
                          {/* Beobachtung */}
                          <div className="bg-[#fbfcff] p-4 rounded-xl border border-blue-100 space-y-1.5">
                            <span className="text-[10px] font-mono text-blue-500 uppercase tracking-widest font-bold block mb-1">
                              🔍 Empirische Beobachtung (Systemisch)
                            </span>
                            <p className="text-xs text-slate-700 leading-relaxed">
                              {selectedWord.observation}
                            </p>
                          </div>

                          {/* Interpretation */}
                          <div className="bg-[#fffdfc] p-4 rounded-xl border border-orange-100 space-y-1.5">
                            <span className="text-[10px] font-mono text-orange-500 uppercase tracking-widest font-bold block mb-1">
                              💡 Soziolinguistische Interpretation
                            </span>
                            <p className="text-xs text-slate-700 leading-relaxed">
                              {selectedWord.interpretation}
                            </p>
                          </div>

                        </div>

                        {/* 4. Comparison with Reference Dictionaries */}
                        {selectedWord.reference && (
                          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                            <div className="flex items-center gap-1.5 text-[10px] font-mono text-slate-500 uppercase tracking-wider mb-2">
                              <Info className="w-3 h-3 text-slate-450" /> Abgleich mit Referenzwörterbüchern
                            </div>
                            <blockquote className="text-xs text-slate-600 italic border-l-2 border-slate-300 pl-3 leading-relaxed">
                              {selectedWord.reference}
                            </blockquote>
                          </div>
                        )}

                        {/* Text citation */}
                        <div className="bg-slate-100/50 p-3 rounded-lg font-mono text-[10px] text-slate-500 flex items-center justify-between">
                          <span>Belegstelle im Text</span>
                          <span className="italic">"{selectedWord.word}"</span>
                        </div>

                      </div>
                    </motion.div>
                  ) : (
                    <div className="bg-white rounded-2xl border border-slate-200 p-8 text-center text-slate-500 space-y-4">
                      <HelpCircle className="w-12 h-12 text-slate-350 mx-auto stroke-[1]" />
                      <div className="space-y-1">
                        <h3 className="font-serif font-bold text-slate-900 text-lg">Kein Begriff selektiert</h3>
                        <p className="text-sm max-w-sm mx-auto leading-normal">
                          Wählen Sie eines der markierten Wörter im Text, um dessen tiefenlinguistisches Dossier und etymologische Brüche aufzudecken.
                        </p>
                      </div>
                    </div>
                  )}
                </AnimatePresence>
              </div>

            </div>

            {/* SIMPLIFIED STATS & SCIENTIFIC INSIGHTS */}
            <div className="mt-10 pt-10 border-t border-slate-200 space-y-8 animate-fadeIn">
              <div className="border-l-4 border-amber-500 pl-4">
                <h3 className="text-xl font-serif font-bold text-slate-900">
                  Linguistische Gesamt-Analyse &amp; Statistische Auswertung
                </h3>
                <p className="text-xs text-slate-500 font-mono mt-1">
                  Verteilung historischer Einflüsse, Herkunftssprachen und Belegstellen im untersuchten Text
                </p>
              </div>

              {/* Simple stats cards */}
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
                  <span className="text-[10px] font-mono text-slate-400 uppercase tracking-widest block font-bold">Gesamt-Entlehnungen</span>
                  <div className="text-3xl font-serif font-bold text-slate-900 mt-1">{stats.total}</div>
                  <p className="text-xs text-slate-500 mt-1.5 leading-relaxed">
                    Identifizierte Wörter mit Wurzeln aus anderen Kontaktsprachen.
                  </p>
                </div>

                <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
                  <span className="text-[10px] font-mono text-slate-400 uppercase tracking-widest block font-bold">Verhältnis (Fremdwort vs. Lehnwort)</span>
                  <div className="text-2xl font-serif font-bold text-teal-700 mt-1">
                    {stats.classCounts["Lehnwort"] || 0} <span className="text-xs font-mono text-slate-500 font-normal">Lehnwörter vs. {stats.classCounts["Fremdwort"] || 0} Fremdwörter</span>
                  </div>
                  <p className="text-xs text-slate-500 mt-1.5 leading-relaxed">
                    Klassifikation nach dem Grad der orthographischen &amp; morphologischen Anpassung an das Deutsche.
                  </p>
                </div>

                <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
                  <span className="text-[10px] font-mono text-slate-400 uppercase tracking-widest block font-bold">Häufigste Herkunft</span>
                  <div className="text-2xl font-serif font-bold text-slate-900 mt-1">
                    {Object.entries(stats.langCounts).sort((a, b) => (b[1] as number) - (a[1] as number))[0]?.[0] || "Keine"}
                  </div>
                  <p className="text-xs text-slate-500 mt-1.5 leading-relaxed">
                    Die dominierende Herkunftssprache der Entlehnungen in dieser Passage.
                  </p>
                </div>
              </div>

              {/* Grid for Summary Table & Sources */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
                
                {/* Left: Summary Table */}
                <div className="lg:col-span-7 bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
                  <div className="space-y-1">
                    <h4 className="text-sm font-serif font-bold text-slate-900 flex items-center gap-1.5 border-b border-slate-100 pb-2">
                      <Database className="w-4 h-4 text-amber-600" /> Übersicht nach Sprache und Klassifikation
                    </h4>
                    <p className="text-xs text-slate-500">
                      Sortiert und gruppiert nach grammatikalischem Integrationsgrad.
                    </p>
                  </div>
                  <div className="overflow-x-auto border border-slate-100 rounded-xl">
                    <table className="w-full text-left border-collapse text-xs">
                      <thead>
                        <tr className="bg-slate-50 border-b border-slate-200 text-slate-550 font-mono text-[9px] uppercase tracking-wider">
                          <th className="px-3 py-2.5 font-bold">Wortklasse</th>
                          <th className="px-3 py-2.5 font-bold">Herkunftssprache</th>
                          <th className="px-3 py-2.5 font-bold text-center">Belege</th>
                          <th className="px-3 py-2.5 font-bold text-center">Anteil (%)</th>
                          <th className="px-3 py-2.5 font-bold">Wörter</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {statisticalSummary.map((row, idx) => (
                          <tr key={idx} className="hover:bg-slate-50/50">
                            <td className="px-3 py-2.5 whitespace-nowrap">
                              <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-medium ${
                                row.classification === "Fremdwort"
                                  ? "bg-orange-50 text-orange-700 border border-orange-100"
                                  : row.classification === "Lehnwort"
                                  ? "bg-teal-50 text-teal-700 border border-teal-100"
                                  : row.classification === "Vollständig integriert"
                                  ? "bg-cyan-50 text-cyan-700 border border-cyan-100"
                                  : "bg-fuchsia-50 text-fuchsia-700 border border-fuchsia-100"
                              }`}>
                                {row.classification}
                              </span>
                            </td>
                            <td className="px-3 py-2.5 font-medium text-slate-800 whitespace-nowrap">{row.origin}</td>
                            <td className="px-3 py-2.5 font-mono text-center font-bold text-slate-950">{row.count}</td>
                            <td className="px-3 py-2.5 font-mono text-center text-slate-500">{row.percentage}%</td>
                            <td className="px-3 py-2.5 text-slate-600 font-mono text-[10px]">
                              <div className="flex flex-wrap gap-1 max-w-[240px]">
                                {row.words.map((w, wIdx) => (
                                  <span key={wIdx} className="bg-slate-100 text-slate-800 px-1.5 py-0.5 rounded">
                                    {w}
                                  </span>
                                ))}
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Right: Scientific Context & Sources */}
                <div className="lg:col-span-5 bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
                  <h4 className="text-sm font-serif font-bold text-slate-900 flex items-center gap-1.5 border-b border-slate-100 pb-2">
                    <BookOpen className="w-4 h-4 text-emerald-600" /> Wissenschaftliche Einordnung &amp; Quellen
                  </h4>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    Die systematische Untersuchung belegt eine vielschichtige Strukturierung fremdsprachlicher Einströme. Das Korpus spiegelt die wesentlichen Entwicklungswellen des Sprachkontakts im mitteleuropäischen Kulturraum wider – von klassischen lateinischen und griechischen Bildungswurzeln über barocke französische Hofbegriffe bis hin zur modernen angelsächsischen Digital-Terminologie.
                  </p>
                  
                  <div className="bg-slate-50 p-4 rounded-xl border border-slate-150 space-y-2.5">
                    <span className="text-[10px] font-mono text-slate-400 uppercase tracking-widest block font-bold font-mono">Etymologische Referenzwerke:</span>
                    <div className="space-y-2 text-xs text-slate-600 leading-relaxed">
                      <div className="flex items-start gap-1.5">
                        <span className="text-amber-600 font-bold">•</span>
                        <span>
                          <strong>DWDS (Etymologisches Wörterbuch):</strong>{" "}
                          <a 
                            href="https://www.dwds.de/d/wb-etymwb" 
                            target="_blank" 
                            rel="noopener noreferrer" 
                            className="text-blue-600 hover:underline inline-flex items-center"
                          >
                            dwds.de/d/wb-etymwb
                          </a>
                        </span>
                      </div>
                      <div className="flex items-start gap-1.5">
                        <span className="text-amber-600 font-bold">•</span>
                        <span>
                          <strong>Wörterbuchnetz (Universität Trier):</strong>{" "}
                          <a 
                            href="https://woerterbuchnetz.de" 
                            target="_blank" 
                            rel="noopener noreferrer" 
                            className="text-blue-600 hover:underline inline-flex items-center"
                          >
                            woerterbuchnetz.de
                          </a>
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

              </div>

              {/* Compact list of all word observations */}
              <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
                <h4 className="text-sm font-serif font-bold text-slate-900 flex items-center gap-1.5 border-b border-slate-100 pb-2">
                  <CheckCircle className="w-4 h-4 text-emerald-600" /> Systematische Einzelbelege &amp; empirische Beobachtungen
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-h-80 overflow-y-auto pr-2">
                  {activeWords.map((w) => (
                    <div key={w.id} className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl space-y-2 text-xs text-slate-700">
                      <div className="flex items-center justify-between">
                        <span className="font-serif font-bold text-slate-950 text-sm">{w.word} <span className="font-normal text-slate-500 font-sans text-xs">({w.lemma})</span></span>
                        <span className={`px-2 py-0.5 rounded text-[10px] font-semibold ${
                          w.classification === "Fremdwort"
                            ? "bg-orange-50 text-orange-700 border border-orange-100"
                            : "bg-teal-50 text-teal-700 border border-teal-100"
                        }`}>
                          {w.classification}
                        </span>
                      </div>
                      <div className="text-slate-600 leading-relaxed font-sans">
                        <strong className="text-slate-500 font-mono text-[10px] uppercase block mb-0.5 font-mono">Linguistische Beobachtung:</strong>
                        {w.observation}
                      </div>
                      {w.reference && (
                        <div className="text-[11px] text-slate-650 italic border-l-2 border-slate-300 pl-2 bg-white/60 p-1.5 rounded-r">
                          {w.reference}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </>
        )
      )}

          {/* TAB 2: STATISTICS CENTER & TABULAR COMPILATION - REMOVED */}
          {false && (
            <div className="space-y-8 animate-fadeIn">
              
              {/* Stat Bento cards */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                
                {/* Card 1: Quantitativer Befund */}
                <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-3">
                  <span className="text-[10px] font-mono text-slate-400 uppercase tracking-widest block">
                    Quantitativer Befund
                  </span>
                  <div className="flex items-baseline gap-2">
                    <span className="text-4xl font-serif font-bold text-slate-900">{stats.total}</span>
                    <span className="text-xs text-slate-500 font-mono">Entlehnungen</span>
                  </div>
                  <p className="text-xs text-slate-600 leading-normal pt-1">
                    Anzahl der registrierten Wörter, die nachgewiesenermaßen aus Kontaktsprachen in den Text eingeflossen sind.
                  </p>
                </div>

                {/* Card 2: Dominanter Einflussfaktor */}
                <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-3">
                  <span className="text-[10px] font-mono text-slate-400 uppercase tracking-widest block">
                    Historisch dominant
                  </span>
                  <div className="flex items-baseline gap-2">
                    <span className="text-4xl font-serif font-semibold text-red-700">
                      {stats.langCounts["Französisch"] || 0}
                    </span>
                    <span className="text-xs text-slate-500 font-mono">Gallizismen (Französisch)</span>
                  </div>
                  <p className="text-xs text-slate-600 leading-normal pt-1">
                    Das Französische stellt mit seinen traditionsreichen Mode- und Medienbegriffen den stärksten Sprachkontakt-Zulauf in dieser Textpassage dar.
                  </p>
                </div>

                {/* Card 3: Integrations-Index */}
                <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-3">
                  <span className="text-[10px] font-mono text-slate-400 uppercase tracking-widest block">
                    Strukturverhältnis
                  </span>
                  <div className="flex items-baseline gap-2">
                    <span className="text-4xl font-serif font-bold text-teal-700">
                      {stats.classCounts["Lehnwort"] || 0}
                    </span>
                    <span className="text-xs text-slate-550 font-mono">Lehnwörter vs. {stats.classCounts["Fremdwort"] || 0} Fremdwörter</span>
                  </div>
                  <p className="text-xs text-slate-600 leading-normal pt-1">
                    Überlegenheit der Lehnwörter deutet darauf hin, dass die Mehrzahl der Fremdlinge grammatisch fest ins Deutsche integriert wurde.
                  </p>
                </div>

              </div>

              {/* Graphical distribution section */}
              <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs">
                <h3 className="text-lg font-serif font-bold text-slate-900 mb-6 flex items-center gap-1.5">
                  <Globe className="w-5 h-5 text-amber-600" /> Statistische Verteilung der Fremdeinflüsse
                </h3>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  
                  {/* Gauge 1: Herkunfts-Verteilung */}
                  <div className="space-y-4">
                    <h4 className="text-xs font-mono text-slate-400 uppercase tracking-wider">
                      1. Verteilung nach Herkunftssprache (Entlehnungen)
                    </h4>
                    <div className="space-y-3 pt-1">
                      {Object.entries(stats.langCounts)
                        .sort((a, b) => (b[1] as number) - (a[1] as number))
                        .map(([lang, count]) => {
                          const percentage = Math.round(((count as number) / stats.total) * 100);
                          let colorHex = "bg-blue-500";
                          if (lang === "Französisch") colorHex = "bg-red-500";
                          if (lang === "Latein") colorHex = "bg-amber-500";
                          if (lang === "Griechisch/Mehrstufig") colorHex = "bg-indigo-500";
                          if (lang === "Gemischt (Mischform)") colorHex = "bg-purple-500";
                          return (
                            <div key={lang} className="space-y-1">
                              <div className="flex justify-between items-baseline text-xs">
                                <span className="font-medium text-slate-800">{lang}</span>
                                <span className="text-slate-500 font-mono">{count} ({percentage}%)</span>
                              </div>
                              <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
                                <div className={`${colorHex} h-full rounded-full`} style={{ width: `${percentage}%` }} />
                              </div>
                            </div>
                          );
                        })}
                    </div>
                  </div>

                  {/* Gauge 2: Integrations-Index */}
                  <div className="space-y-4">
                    <h4 className="text-xs font-mono text-slate-400 uppercase tracking-wider">
                      2. Integrationsgrad der Entlehnungen
                    </h4>
                    <div className="space-y-3 pt-1">
                      {Object.entries(stats.classCounts)
                        .sort((a, b) => (b[1] as number) - (a[1] as number))
                        .map(([level, count]) => {
                          const percentage = Math.round(((count as number) / stats.total) * 100);
                          let colorHex = "bg-orange-500";
                          if (level === "Lehnwort") colorHex = "bg-teal-500";
                          if (level === "Vollständig integriert") colorHex = "bg-cyan-500";
                          if (level === "Unsicher") colorHex = "bg-fuchsia-500";
                          return (
                            <div key={level} className="space-y-1">
                              <div className="flex justify-between items-baseline text-xs">
                                <span className="font-medium text-slate-800">{level}</span>
                                <span className="text-slate-550 font-mono">{count} ({percentage}%)</span>
                              </div>
                              <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
                                <div className={`${colorHex} h-full rounded-full`} style={{ width: `${percentage}%` }} />
                              </div>
                            </div>
                          );
                        })}
                    </div>
                  </div>

                </div>
              </div>

              {/* Statistische Übersichtstabelle nach Fremd- oder Lehnwort und Sprache */}
              <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
                <div className="space-y-1">
                  <h3 className="text-lg font-serif font-bold text-slate-900 flex items-center gap-2">
                    <Database className="w-5 h-5 text-teal-600" /> Statistische Übersicht der Entlehnungen pro Sprache
                  </h3>
                  <p className="text-xs text-slate-500">
                    Wissenschaftliche Tabellen-Kompilation nach grammatikalischem Integrationsgrad (Fremdwort vs. Lehnwort) und Herkunftssprache.
                  </p>
                </div>
                <div className="overflow-x-auto border border-slate-100 rounded-xl">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-mono text-[9px] uppercase tracking-wider">
                        <th className="px-4 py-3 font-bold">Wortklasse (Einstufung)</th>
                        <th className="px-4 py-3 font-bold">Herkunftssprache</th>
                        <th className="px-4 py-3 font-bold text-center">Anzahl Belege</th>
                        <th className="px-4 py-3 font-bold text-center">Anteil (%)</th>
                        <th className="px-4 py-3 font-bold">Gefundene Wörter</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {statisticalSummary.map((row, idx) => (
                        <tr key={idx} className="hover:bg-slate-50/70 transition-colors">
                          <td className="px-4 py-3">
                            <span className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-semibold ${
                              row.classification === "Fremdwort"
                                ? "bg-orange-50/70 border border-orange-200/40 text-orange-700"
                                : row.classification === "Lehnwort"
                                ? "bg-teal-50/70 border border-teal-200/40 text-teal-700"
                                : row.classification === "Vollständig integriert"
                                ? "bg-cyan-50/70 border border-cyan-200/40 text-cyan-700"
                                : "bg-fuchsia-50/70 border border-fuchsia-200/40 text-fuchsia-700"
                            }`}>
                              {row.classification}
                            </span>
                          </td>
                          <td className="px-4 py-3 font-medium text-slate-800">
                            {row.origin}
                          </td>
                          <td className="px-4 py-3 font-mono text-center font-bold text-slate-900">{row.count}</td>
                          <td className="px-4 py-3 font-mono text-center text-slate-550">{row.percentage}%</td>
                          <td className="px-4 py-3 text-slate-600 font-mono text-[10px]">
                            <div className="flex flex-wrap gap-1 max-w-md">
                              {row.words.map((w, wIdx) => (
                                <span key={wIdx} className="bg-slate-100 text-slate-705 px-1.5 py-0.5 rounded">
                                  {w}
                                </span>
                              ))}
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* CORE TABLE AS REQUIRED BY USER */}
              <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
                
                {/* Search and Filters Header */}
                <div className="p-6 border-b border-slate-200 space-y-4">
                  <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4">
                    <div className="space-y-1">
                      <h3 className="text-lg font-serif font-bold text-slate-900">
                        Systematische Übersichtstabelle
                      </h3>
                      <p className="text-xs text-slate-500">
                        Wissenschaftliche Tabellierung der Entlehnungen, sortiert und filterbar nach Fremd- oder Lehnwort und Sprache.
                      </p>
                    </div>

                    {/* Integrated Search Input */}
                    <div className="relative w-full md:w-72">
                      <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                      <input
                        type="text"
                        placeholder="Wort oder Begriff filtern..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="w-full text-xs rounded-lg border border-slate-350 pl-9 pr-4 py-2 bg-slate-50 focus:outline-none focus:ring-1 focus:ring-amber-500 focus:bg-white"
                      />
                    </div>
                  </div>

                  {/* Criteria filters */}
                  <div className="flex flex-wrap gap-4 items-center">
                    
                    {/* Class Filter */}
                    <div className="flex items-center gap-1.5 text-xs">
                      <span className="text-slate-500">Einstufung:</span>
                      <select
                        value={classificationFilter}
                        onChange={(e) => setClassificationFilter(e.target.value)}
                        className="rounded-lg bg-slate-100 border border-slate-300 py-1 px-2.5 outline-none hover:bg-slate-200 transition-all cursor-pointer"
                      >
                        <option value="all">Alle Kategorien</option>
                        <option value="Fremdwort">Fremdwörter</option>
                        <option value="Lehnwort">Lehnwörter</option>
                        <option value="Vollständig integriert">Vollständig integrierte</option>
                        <option value="Unsicher">Unsicher / Grenzfälle</option>
                      </select>
                    </div>

                    {/* Origin Language Filter */}
                    <div className="flex items-center gap-1.5 text-xs">
                      <span className="text-slate-500">Herkunftssprache:</span>
                      <select
                        value={originFilter}
                        onChange={(e) => setOriginFilter(e.target.value)}
                        className="rounded-lg bg-slate-100 border border-slate-300 py-1 px-2.5 outline-none hover:bg-slate-200 transition-all cursor-pointer"
                      >
                        <option value="all">Alle Sprachen</option>
                        {Array.from(new Set(activeWords.map((w) => w.origin))).filter(Boolean).sort().map((orig) => (
                          <option key={orig} value={orig}>{orig}</option>
                        ))}
                      </select>
                    </div>

                    <div className="font-mono text-[10px] text-slate-400 ml-auto">
                      {filteredWords.length} von {activeWords.length} Einträgen angezeigt
                    </div>

                  </div>
                </div>

                {/* Actual Table */}
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="bg-slate-50 border-b border-slate-200 font-mono text-[10px] text-slate-400 select-none uppercase">
                        <th 
                          onClick={() => toggleSort("word")}
                          className="px-6 py-4.5 font-bold cursor-pointer hover:bg-slate-100 transition-all"
                        >
                          Wort / Beleg {sortField === "word" ? (sortDirection === "asc" ? "▲" : "▼") : ""}
                        </th>
                        <th className="px-6 py-4.5 font-bold">Grundform & Wanderungs-Details</th>
                        <th 
                          onClick={() => toggleSort("origin")}
                          className="px-6 py-4.5 font-bold cursor-pointer hover:bg-slate-100 transition-all"
                        >
                          Herkunftssprache {sortField === "origin" ? (sortDirection === "asc" ? "▲" : "▼") : ""}
                        </th>
                        <th 
                          onClick={() => toggleSort("classification")}
                          className="px-6 py-4.5 font-bold cursor-pointer hover:bg-slate-100 transition-all"
                        >
                          Linguistische Einstufung {sortField === "classification" ? (sortDirection === "asc" ? "▲" : "▼") : ""}
                        </th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-150 text-xs md:text-sm">
                      {filteredWords.length > 0 ? (
                        filteredWords.map((w, index) => (
                          <tr 
                            key={w.id} 
                            onClick={() => {
                              setSelectedWord(w);
                              setActiveTab("explorer");
                            }}
                            className={`hover:bg-slate-50/70 transition-all cursor-pointer ${index % 2 === 0 ? "bg-white" : "bg-slate-50/20"}`}
                          >
                            {/* Word */}
                            <td className="px-6 py-4">
                              <span className="font-serif font-bold text-slate-950 block">{w.word}</span>
                              <span className="text-[10px] text-slate-400 italic">"{w.exampleSentence.substring(0, 35)}..."</span>
                            </td>

                            {/* Lemma & Path */}
                            <td className="px-6 py-4 space-y-1 select-text max-w-md">
                              <div className="font-mono text-slate-600">Lemma: {w.lemma}</div>
                              <p className="text-xs text-slate-500 leading-normal line-clamp-2">{w.originDetails}</p>
                            </td>

                            {/* Origin */}
                            <td className="px-6 py-4 whitespace-nowrap">
                              <span className={`px-2 py-0.5 rounded text-[10px] font-mono ${
                                w.origin === "Englisch" 
                                  ? "bg-blue-50 text-blue-800 border border-blue-200"
                                  : w.origin === "Französisch" 
                                  ? "bg-red-50 text-red-800 border border-red-200"
                                  : "bg-amber-50 text-amber-800 border border-amber-200"
                              }`}>
                                {w.origin}
                              </span>
                            </td>

                            {/* Tag class */}
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div className="flex flex-col gap-0.5">
                                <span className="font-medium text-slate-800">{w.classification}</span>
                                <span className="text-[10px] text-slate-400 max-w-[200px] truncate">{w.reason}</span>
                              </div>
                            </td>
                          </tr>
                        ))
                      ) : (
                        <tr>
                          <td colSpan={4} className="px-6 py-12 text-center text-slate-400 font-mono">
                            Keine Einträge für diese Filtereinstellungen gefunden.
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>

                {/* Table Footer */}
                <div className="p-4 bg-slate-50 border-t border-slate-150 text-center text-[11px] text-slate-400 font-mono">
                  💡 Klicken Sie auf eine Tabellenzeile, um das Wort direkt im Text-Explorer zu inspizieren.
                </div>

              </div>

            </div>
          )}



          {/* TAB 4: CHATTER SYSTEM (ASK EXPERT) */}
          {activeTab === "chat" && (
            <div className="max-w-4xl mx-auto bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs flex flex-col h-[70vh]">
              
              {/* Chat upper label */}
              <div className="bg-slate-900 p-4 text-white flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="bg-amber-500/10 text-amber-400 p-2 rounded-lg border border-amber-500/20">
                    <Brain className="w-5 h-5 text-amber-500" />
                  </div>
                  <div>
                    <h3 className="font-serif font-bold text-sm tracking-wide text-white">Ety – Dein etymologischer Dialog-Assistent</h3>
                    <p className="text-[10px] text-slate-400 font-mono">Linguistische Expertise für Etymologie & Sprachkontakt</p>
                  </div>
                </div>

                <div className="text-xs text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded font-mono border border-amber-500/20">
                  Gemini API online
                </div>
              </div>

              {/* Scrollable conversation bubble yard */}
              <div className="flex-1 overflow-y-auto p-6 bg-slate-50 space-y-4">
                {chatMessages.map((msg) => (
                  <div 
                    key={msg.id} 
                    className={`flex gap-3 items-start ${msg.role === "user" ? "justify-end" : "justify-start"}`}
                  >
                    {msg.role !== "user" && (
                      <div className="flex flex-col items-center gap-1 shrink-0 select-none">
                        <div className="w-8 h-8 rounded-full bg-slate-900 border border-slate-700 flex items-center justify-center text-amber-400 shadow-sm animate-fadeIn">
                          <Bot className="w-4 h-4 text-amber-400 stroke-[1.8]" />
                        </div>
                        <span className="text-[9px] font-mono font-bold text-slate-500 uppercase tracking-wider">Ety</span>
                      </div>
                    )}
                    <div 
                      className={`max-w-[80%] rounded-2xl p-4 text-xs md:text-sm shadow-2xs leading-relaxed ${
                        msg.role === "user"
                          ? "bg-amber-500 text-slate-950 font-medium rounded-tr-none"
                          : "bg-white text-slate-800 border border-slate-150 rounded-tl-none whitespace-pre-line"
                      }`}
                    >
                      {/* Message Content */}
                      <div>{msg.text}</div>
                      
                      {/* Timestamp */}
                      <div className={`text-[9px] mt-2 font-mono text-right ${msg.role === "user" ? "text-slate-800/80" : "text-slate-400"}`}>
                        {msg.timestamp}
                      </div>
                    </div>
                  </div>
                ))}
                
                {/* Streaming / Loading indicator bubblier */}
                {isSendingMessage && (
                  <div className="flex gap-3 items-start justify-start">
                    <div className="flex flex-col items-center gap-1 shrink-0 select-none">
                      <div className="w-8 h-8 rounded-full bg-slate-900 border border-slate-700 flex items-center justify-center text-amber-400 shadow-sm">
                        <Bot className="w-4 h-4 text-amber-400 stroke-[1.8] animate-pulse" />
                      </div>
                      <span className="text-[9px] font-mono font-bold text-slate-500 uppercase tracking-wider">Ety</span>
                    </div>
                    <div className="bg-white text-slate-800 border border-slate-150 rounded-2xl rounded-tl-none p-4 shadow-2xs flex items-center gap-2">
                      <div className="w-1.5 h-1.5 rounded-full bg-slate-400 animate-bounce" style={{ animationDelay: "0ms" }} />
                      <div className="w-1.5 h-1.5 rounded-full bg-slate-400 animate-bounce" style={{ animationDelay: "150ms" }} />
                      <div className="w-1.5 h-1.5 rounded-full bg-slate-400 animate-bounce" style={{ animationDelay: "300ms" }} />
                      <span className="text-xs text-slate-400 font-mono pl-1">Ety formuliert...</span>
                    </div>
                  </div>
                )}
                
                <div ref={chatBottomRef} />
              </div>

              {/* Bottom Send Action area */}
              <div className="p-4 border-t border-slate-200 bg-white">
                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder="Fragen Sie z. B.: Erkläre die Herkunftskette von Magazin von Arabisch nach Deutsch."
                    value={chatInput}
                    onChange={(e) => setChatInput(e.target.value)}
                    onKeyDown={(e) => e.key === "Enter" && handleSendMessage()}
                    className="flex-1 text-xs md:text-sm rounded-xl border border-slate-300 px-4 py-3 bg-slate-50 focus:outline-none focus:ring-1 focus:ring-amber-500 focus:bg-white"
                  />
                  <button
                    onClick={handleSendMessage}
                    disabled={isSendingMessage || !chatInput.trim()}
                    className="bg-slate-900 border border-slate-950 hover:bg-slate-850 active:bg-slate-950 text-white p-3 rounded-xl transition-all disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer shrink-0"
                  >
                    <Send className="w-4 h-4" />
                  </button>
                </div>
                
                <div className="mt-2.5 flex items-center justify-between text-[10px] font-mono text-slate-400">
                  <span>Modell: Gemini 3.5 Flash</span>
                  <span>*Basiert wissenschaftlich auf dem aktuellen Wortkontingent*</span>
                </div>
              </div>

            </div>
          )}

        </div>

      </main>

      {/* Elegant Academic footer */}
      <footer className="border-t border-slate-200 bg-white/60 py-10 text-center text-slate-400 mt-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-2 select-none">
          <p className="text-xs font-serif font-semibold text-slate-700">
            Linguistischer Etymologie-Assistent
          </p>
          <p className="text-[10px] font-mono max-w-md mx-auto leading-normal">
            Lizensiert zur Erforschung von Kontaktsprachen und soziosemantischen Adaptionsmustern im synchronen und diachronen deutschen Sprachgebrauch.
          </p>
          <p className="text-[9px] font-mono text-slate-400 pt-3">
            © 2026 • Entwickelt für wissenschaftliche Präzision.
          </p>
        </div>
      </footer>

    </div>
  );
}
