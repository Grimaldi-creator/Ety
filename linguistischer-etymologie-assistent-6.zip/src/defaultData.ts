export interface WordEntry {
  id: string;
  word: string;
  lemma: string;
  origin: string;
  classification: "Fremdwort" | "Lehnwort" | "Vollständig integriert" | "Unsicher";
  originDetails: string;
  reason: string;
  observation: string;
  interpretation: string;
  reference: string;
  exampleSentence: string;
  lexemeForms?: string;
}

export const ORIGINAL_TEXT_PART_1 = 
  "Auf die Frage, ob sie Social Media nutze, antwortet Elfie Semotan, dass man da ja gar nicht mehr drum herumkomme, sie aber dort nie selbst etwas poste. “Ich habe ehrlich gesagt zu wenig Zeit dafür”, erklärt sie. Mit 82 Jahren ist bei der vielleicht bekanntesten österreichischen Fotografin an Ruhestand nicht zu denken. Semotan besuchte zunächst eine Modeschule und ging dann mit 20 als Model nach Paris, bevor sie begann, selbst zu fotografieren. In den späten Siebzigerjahren sorgte ihre Werbekampagne für Palmers mit einer ungewohnt verführerischen, aber selbstbewussten Frauendarstellung für einen Skandal; der einfühlsamen Begegnung mit ihren Sujets auf Augenhöhe sollte sie immer treu bleiben. Semotan fotografiert seit über 40 Jahren Porträts und Editorials für die renommiertesten Magazine der Welt: Besonders ihre langjährige Zusammenarbeit mit ihrem besten Freund, dem Modedesigner Helmut Lang, ist stilprägend für die Neunzigerjahre. Generell wird ihre Arbeit immer wieder befruchtet durch den Austausch mit anderen Kreativen – wie ihren beiden Ehemännern Kurt Kocherscheidt (1943–1992) und Martin Kippenberger (1953–1997). Heute fotografiert Semotan vor allem Stillleben und Porträts; derzeit sind Werke von ihr in Gruppenausstellungen in unter anderem Prag und New York zu sehen, es läuft eine Einzelausstellung in Linz und ganz aktuell auch in der Landesgalerie Burgenland.";

export const ORIGINAL_TEXT_PART_2 =
  "Dort, im Burgenland, ein paar Kilometer von Jennersdorf entfernt, bewohnt Semotan seit rund 50 Jahren ein altes Bauernhaus. Trotz zahlreicher anderer Stationen ist es für sie stets ein Ort der Rückkehr, der Konzentration und Verarbeitung geblieben. Das Haus wurde kontinuierlich umgebaut und erweitert, seinem Innenleben merkt man die Bewegtheit von Semotans Leben in jeder Ecke an, überall finden sich persönliche Memorabilien, Arbeiten und Flohmarktfunde, alles ist erfrischend ungestylt.";

export const DEFAULT_TEXT = `${ORIGINAL_TEXT_PART_1}\n\n${ORIGINAL_TEXT_PART_2}`;

export const LINGUISTIC_DATA: WordEntry[] = [
  {
    id: "social_media",
    word: "Social Media",
    lemma: "Social Media",
    origin: "Englisch",
    classification: "Fremdwort",
    originDetails: "Moderne englische Wortzusammensetzung aus 'social' (lat. 'socialis' = kameradschaftlich, gesellschaftlich) und 'media' (lat. Neutrum-Plural von 'medium' = Mitte, Vermittler). Als Kompositum im späten 20. Jahrhundert im angloamerikanischen Raum entstanden und als globale Phrase entlehnt.",
    reason: "Verbleibt im Deutschen weitgehend unintegriert: Es bewahrt die englische Originalschreibung (ohne Bindestrich, getrennt, Großschreibung teils an deutsches Nomen angepasst, oft aber auch wie ein englisches Eigennamenkonstrukt behandelt), die englische Phonik ([ˈsoʊʃəl ˈmiːdiə]) und zeigt keine deutsche Flexionsendung auf.",
    observation: "Objektives Schriftbild und Lautung: Beibehaltung der englischen Schreibweise und Lautung. Es gibt kein deutsches grammatisches Muster, das diese Wortverbindung im Text dekliniert (tritt hier im Dativ/Akkusativ-Kontext unflektiert nach 'ob sie' auf).",
    interpretation: "Soziolinguistisches Motiv: Das Wort wird als Ausdruck digitaler Modernität und Internationalität verwendet. Es zeigt die rasante Übernahme angelsächsischer Leitbegriffe im Medienjargon. Es fungiert als unhinterfragter Alltagsbegriff in der Gegenwartskommunikation.",
    reference: "Duden Fremdwörterbuch: Verzeichnet als Fremdwort, sächlich oder Plural (vorwiegend Plural), Herkunft: englisch 'social media'.",
    exampleSentence: "Auf die Frage, ob sie Social Media nutze, antwortet Elfie Semotan...",
    lexemeForms: "Nomen: Social Media (Singular & Plural)"
  },
  {
    id: "poste",
    word: "poste",
    lemma: "posten",
    origin: "Englisch",
    classification: "Lehnwort",
    originDetails: "Eingedeutschtes Verb, entlehnt von englisch 'to post' (Inhalte im Internet veröffentlichen). Dieses lässt sich etymologisch über altfranzösisch 'poste' auf das lateinische 'ponere' (stellen, legen) zurückführen. Der Internet-Sinn ist jedoch ein reines Produkt des englischen Web-Zeitalters.",
    reason: "Perfektes Beispiel für ein Lehnwort: Der englische Verbstamm 'post-' wurde vollständig in das deutsche Konjugationsparadigma überführt. Konjugiert nach der schwachen deutschen Konjugation (posten, postete, gepostet). Hier im Text flektiert mit der deutschen Endung '-e' für die 3. Person Singular im Konjunktiv I ('...dass sie ... nie selbst etwas poste').",
    observation: "Morphologische Flexion: Der Stamm 'post-' ist mit der deutschen Konjunktiv-Präsens-Endung '-e' versehen. Rechtschreibung is kleingeschrieben wie alle deutschen Verben.",
    interpretation: "Schnittstelle Internetökonomie und Alltagssprache: Notwendigkeit, ein handhabbares deutsches Verb für eine neue Kulturpraxis zu etablieren. Anstatt 'Inhalte veröffentlichen' zu umschreiben, wird die grammatikalische Flexibilität des Deutschen genutzt, um das Fremdwort zu einem voll funktionstüchtigen Lehnverb zu assimilieren.",
    reference: "Kluge, Etymologisches Wörterbuch: 'posten' als Internetbegriff aufgenommen, Einordnung als Lehn-Verbindung aus dem Englischen des späten 20. Jahrhunderts.",
    exampleSentence: "...sie aber dort nie selbst etwas poste.",
    lexemeForms: "Verb: posten, Nomen: Post (der/das, Plural: Posts), Adjektiv-Partizip: gepostet"
  },
  {
    id: "fotografin",
    word: "Fotografin",
    lemma: "Fotografin",
    origin: "Griechisch/Mehrstufig",
    classification: "Vollständig integriert",
    originDetails: "Aus griechisch 'phōs' (Licht, Genitiv 'phōtos') und 'graphein' (schreiben, zeichnen). Über das französische Substantiv 'photographie' im 19. Jahrhundert ins Deutsche vermittelt und dort morphologisch modifiziert.",
    reason: "Aufgrund der vollständigen graphischen, phonologischen und morphologischen Assimilation im deutschen Sprachgebrauch nicht mehr als typisches Fremdwort gewertet. Die Orthographie wurde vollständig eingedeutscht ('f' statt 'ph'), und es trägt das produktive deutsche Femininsuffix '-in'.",
    observation: "Orthographische Eindeutschung: Verwendung von 'F'/'f' anstelle des klassischen griechisch-französischen 'Ph'/'ph' (Fotografin statt Photographin). Nativer Plural 'Fotografinnen' und Flexion.",
    interpretation: "Historischer Sprachkontakt: Zeugnis der Verwissenschaftlichung des 19. Jahrhunderts. Ursprünglich ein künstlich zusammengesetzter Internationalismus, der so tief in die Alltagssprache einsank, dass er heute synchron völlig als deutsches Standardwort wahrgenommen wird.",
    reference: "Duden Herkunftswörterbuch: 'Fotografie' im 19. Jh. aus dem Französischen entlehnt; Reformierte Schreibweise mit 'f' seit Generationen etabliert.",
    exampleSentence: "...bei der vielleicht bekanntesten österreichischen Fotografin...",
    lexemeForms: "Nomen: Fotograf, Fotografin, Fotografie, Foto; Verb: fotografieren; Adjektiv: fotografisch"
  },
  {
    id: "modeschule",
    word: "Modeschule",
    lemma: "Mode",
    origin: "Französisch",
    classification: "Vollständig integriert",
    originDetails: "Gallicismus aus dem 17. Jahrhundert. Entlehnt von französisch 'mode' (Art, Weise, Sitte), welches vom lateinischen Substantiv 'modus' (Maß, Art, Weise) herrührt. Hier als Erstglied im Kompositum 'Modeschule' mit dem germanischen Wort 'Schule'.",
    reason: "Vollständig in den deutschen Wortschatz integriert. Die grammatikalische und phonetische Eindeutschung ist über die vergangenen Jahrhunderte so weit fortgeschritten, dass die französische Wurzel im Alltagsbewusstsein völlig verblasst ist.",
    observation: "Orthographische und phonologische Verschmelzung: Anpassung der Aussprache (stummes französisches e wird im Deutschen als Schwa [ə] realisiert, stimmhaftes [m] im Anlaut). Leicht kombinierbar für Wortzusammensetzungen (Mischkompositum 'Modeschule').",
    interpretation: "Kultureller Sprachkontakt: Zeugnis des enormen Einflusses des französischen Hofstaats im Barockwesen (17. Jh.) auf fast alle sprachlichen Lebensbereiche Zentraleuropas, insbesondere die Kleidungskultur (Feudaljargon).",
    reference: "Kluge: 'Mode' im 17. Jh. aus frz. 'mode' (welches im Französischen weiblichen Geschlechts ist, im Gegensatz zum lateinischen 'modus').",
    exampleSentence: "Semotan besuchte zunächst eine Modeschule...",
    lexemeForms: "Nomen: Mode, Modeschule, Modetrend; Adjektiv: modisch, modern"
  },
  {
    id: "model",
    word: "Model",
    lemma: "Model",
    origin: "Englisch",
    classification: "Unsicher",
    originDetails: "Im modernen Sinn (Mannequin) Mitte des 20. Jahrhunderts aus dem Englischen 'model' entlehnt, welches auf französisch 'modèle' und das lateinische 'modulus' (Maßstab) zurückgeht. Im Deutschen gibt es zudem ein homographisches Erbwort/älteres Lehnwort 'Model' (Neutrum/Maskulin, z.B. Backmodel, von mittelhochdeutsch 'model'), was zur Verwechslungsgefahr führt.",
    reason: "Ein hochgradig interessanter Grenzfall der Klassifizierung (daher 'Unsicher'): Es besitzt zwar die englische Kurzschreibweise, ist aber lautsprachlich extrem nah an eine deutsche Realisierung angepasst. Manche Linguisten werten es als Fremdwort, da es die englische Nuance [ˈmɔdl̩] trägt; andere als Lehnwort, da es orthographisch wie ein deutsches Nomen dekliniert werden kann (Plural 'Models' oder gleichbleibend 'Model').",
    observation: "Gedoppeltes Sprachphänomen: Englische Orthographie 'model' wurde im Deutschen teils großgeschrieben übernommen. Die Aussprache im Deutschen weicht von 'Modell' (aus dem Italienischen) ab und stützt sich auf das englische Phonem.",
    interpretation: "Soziolinguistischer Status: Das Wort verdrängte im späten 20. Jahrhundert fast vollständig die älteren Bezeichnungen 'Mannequin' (französisch) und 'Vorführmädchen' (deutsch) im Zuge der globalisierten Modewelt. Zeugnis der Verschiebung des modischen Leitbilds vom Französischen zum Englischen.",
    reference: "Duden: Aus dem Englischen 'model' für Mannequin, Fotomodell. Davon abzugrenzen ist 'Modell' (über ital. 'modello' im 16. Jh. entlehnt).",
    exampleSentence: "...und ging dann mit 20 als Model nach Paris...",
    lexemeForms: "Nomen: Model, Fotomodell, Modell; Verb: modeln, modellieren; Adjektiv: modellhaft"
  },
  {
    id: "paris",
    word: "Paris",
    lemma: "Paris",
    origin: "Keltisch/Andere",
    classification: "Vollständig integriert",
    originDetails: "Toponym (Eigenname). Zurückzuführen auf den keltischen Stamm der 'Parisii', die in der Antike an der Seine siedelten. Später lateinisch 'Lutetia Parisiorum'.",
    reason: "Als Eigenname (Toponym) ist es ein unveränderlicher Bestandteil der deutschen Sprache (Exonym/Endonym) und wird nicht nach Foreign-Word-Kriterien klassifiziert, gilt aber etymologisch als vorklassisch-keltischen Ursprungs.",
    observation: "Schreibweise entspricht dem französischen und lateinischen Eigennamen. Lautlich im Deutschen angepasst (mit [p] und stimmlosem S, statt des französischen stummen End-s).",
    interpretation: "Geopolitische Kontinuität: Tradierter Eigenname ohne synchrone fremdsprachliche Hürde.",
    reference: "Historische Lexika.",
    exampleSentence: "...als Model nach Paris..."
  },
  {
    id: "kampagne",
    word: "Werbekampagne",
    lemma: "Kampagne",
    origin: "Französisch",
    classification: "Lehnwort",
    originDetails: "Vom französischen 'campagne' (Feld, Flur, offene Landschaft), welches über das lateinische 'campania' auf 'campus' (Feld) zurückgeht. Deutsch im Kompositum 'Werbekampagne'.",
    reason: "Eindeutiges Lehnwort: Die Schreibung wurde mit dem deutschen Graphem 'K' statt des französischen 'C' ausgestattet. Die Aussprache orientiert sich gänzlich an deutschen Phonemregeln ([kamˈpanjə]), das auslautende 'e' wird gesprochen.",
    observation: "Teilassimiliert: Das französische 'gn' (Zungen-Nasal-Laut) wird im Deutschen als 'nj' realisiert ([nj]). Graphische Eindeutschung durch Ersetzung des französischen C durch K.",
    interpretation: "Bedeutungswandel (Semantische Verschiebung): Im 17. und 18. Jahrhundert als Militärbegriff entlehnt ('eine militärische Kampagne' = ein Feldzug im Sommer). Im 20. Jahrhundert wurde dieser kriegerische Begriffsrahmen (Frame) soziosemantisch auf Werbemaßnahmen ('Werbekampagne') und Politik übertragen.",
    reference: "Kluge: 'Kampagne' im 17. Jahrhundert aus dem Französischen entlehnt.",
    exampleSentence: "In den späten Siebzigerjahren sorgte ihre Werbekampagne für Palmers..."
  },
  {
    id: "skandal",
    word: "Skandal",
    lemma: "Skandal",
    origin: "Griechisch/Mehrstufig",
    classification: "Lehnwort",
    originDetails: "Vermittelt über das französische 'scandale', das kirchenlateinische 'scandalum' und letztlich zurückgehend auf das altgriechische 'skandalon' (Fallstrick, Anstoß, Ärgernis).",
    reason: "Lehnwort: Vollständige graphische Eindeutschung ('Sk-' statt französisch/lateinisch 'Sc-'), deutsche Hauptton-Zweitbetonung ([skanˈdaːl]), problemlose deutsche Nominierung und Pluralisierung ('Skandale').",
    observation: "Morphologisch angepasst: Wird wie ein deutsches Maskulinum der starken Deklination dekliniert. Orthographie mit 'k' statt 'c'.",
    interpretation: "Kultur- und Geistesgeschichte: Einstrom theologischer und sittlicher Begriffe im Zuge der Aufklärung, vermittelt über das Französische als westeuropäische Bildungssprache des Adels.",
    reference: "Kluge: Einwanderung des Wortes im 18. Jahrhundert über frz. 'scandale'.",
    exampleSentence: "...sorgte ihre Werbekampagne für Palmers ... für einen Skandal..."
  },
  {
    id: "sujets",
    word: "Sujets",
    lemma: "Sujet",
    origin: "Französisch",
    classification: "Fremdwort",
    originDetails: "Direkt entlehnt von französisch 'sujet' (Gegenstand, Thema, Motiv), welches auf das lateinische Partizip 'subiectum' (das Untergeworfene) zurückzuführen ist.",
    reason: "Klassifiziert als Fremdwort: Die französische Schreibung bleibt im Singular vollkommen unangepasst. Die Phonetik wahrt die französische Aussprache ([syˈʒeː]), das auslautende 't' im Singular wird nicht gesprochen, und der s-Plural ('Sujets') wird mit stimmlosem Reibelaut artikuliert.",
    observation: "Orthographische Auffälligkeit: Der Vokalismus 'uj' und das stumme End-t im Singular sind fremdartig. Pluralendung '-s' ist französisch/fremdwirtschaftlich.",
    interpretation: "Fachjargon und Distinktion: 'Sujet' wird im literarisch-künstlerischen Bereich dem einfacheren deutschen Wort 'Gegenstand' oder 'Motiv' vorgezogen. Es fungiert in der Kunstkritik und Fotoliteratur als Gelehrten- oder Jargonwort zur Signalisierung professioneller Zugehörigkeit.",
    reference: "Duden Fremdwörterbuch: Seit dem 18. Jahrhundert im gehobenen Wortschatz nachweisbar.",
    exampleSentence: "...der einfühlsamen Begegnung mit ihren Sujets auf Augenhöhe..."
  },
  {
    id: "portraets",
    word: "Porträts",
    lemma: "Porträt",
    origin: "Französisch",
    classification: "Lehnwort",
    originDetails: "Aus dem französischen 'portrait' (Bildnis, Darstellung), abgeleitet vom Verb 'portraire' (abmalen, entwerfen), welches auf lateinisch 'protrahere' (hervorziehen) zurückgeht.",
    reason: "Zeigt Merkmale eines Lehnworts durch orthographische Verdeutschung: Das französische 'ai' wurde durch den Umlaut 'ä' ersetzt ('Porträt' statt 'Portrait'). Trotz des verbleibenden End-s im Plural und der endbetonten Aussprache ist die Schreibung stark assimiliert.",
    observation: "Schreibweisen-Variation: Die traditionsreiche Schreibweise 'Portrait' ist zwar noch zulässig, doch die reformierte Fassung 'Porträt' mit Umlaut kennzeichnet die gelungene graphische Anpassung an deutsche Orthographieregeln.",
    interpretation: "Künstlerischer Bereich: Im Barockzeitalter (17. Jh.) mit der Kunsttheorie eingewandert. Heute ein Allgemeinbegriff, der seine ehemals exklusive französische Aura beinahe verloren hat.",
    reference: "Duden Herkunftswörterbuch: Im 17. Jh. entlehnt; Anpassung im 20. Jahrhundert amtlich legitimiert.",
    exampleSentence: "Semotan fotografiert seit über 40 Jahren Porträts und Editorials..."
  },
  {
    id: "editorials",
    word: "Editorials",
    lemma: "Editorial",
    origin: "Englisch",
    classification: "Fremdwort",
    originDetails: "Vom englischen Adjektiv 'editorial' (redaktionell, das Leitwort betreffend), welches auf lateinisch 'editor' (Herausgeber) fußt. Im Deutschen substantiviert im Bereich der Zeitschriftenforschung und des Modedesigns.",
    reason: "Fremdwort: Unangepasste englische Orthographie (z.B. die Vokalfolge '-ia-') und Aussprache ([ɛdɪˈtɔːriəl]). Der Plural wird mit englischem Suffix '-s' gebildet.",
    observation: "Orthographie & Phonologie: Bewahrung des englischen Schriftbilds. Englische Aussprache unberührt.",
    interpretation: "Medien- und Modejargon: Das Wort dient zur Benennung einer großformatigen Fotostrecke in Modemagazinen, die eine redaktionelle Geschichte erzählt. Es grenzt sich damit bewusst von reiner Werbefotografie ab und gehört zum globalisierten Jargon der Modekreativen.",
    reference: "Duden: Zuordnung als neuer Anglizismus (spätes 20. Jahrhundert).",
    exampleSentence: "...Fotografiert seit über 40 Jahren Porträts und Editorials..."
  },
  {
    id: "magazine",
    word: "Magazine",
    lemma: "Magazin",
    origin: "Arabisch",
    classification: "Lehnwort",
    originDetails: "Historische Wanderung: Ursprünglich arabisch 'maḫāzin' (Plural von 'maḫzan' = Vorratshaus, Speicher). Über italienisch 'magazzino' und französisch 'magasin' ins Deutsche gelangt. Entwicklung im Deutschen vom Warenlager zum Periodikum (Zeitschrift).",
    reason: "Vollwertiges Lehnwort: Lautlich völlig germanisiert (stimmhaftes S im Anlaut [magaˈtsiːn], stimmhaftes deutsches Z im Schriftbild). Pluralbildung mit deutschem Schwa-e ('Magazine').",
    observation: "Durchgehende Anpassung: Das arabische 'ḫ' wurde im Romanischen zu 'g' und im Deutschen zu 'g'/'z'. Die Flexion ist nativ schwach maskulin/neutral.",
    interpretation: "Zeugnis der Handels- und Kulturgeschichte: Vom mittelalterlichen Seehandel (Militär- und Vorratslager im maurischen Spanien/Italien) zur Aufklärung, in der 'Magazin' metaphernhaft als 'Speicher des Wissens' für Zeitschriften gewählt wurde.",
    reference: "Kluge: 'Magazin' im 16. Jahrhundert für Lagerhäuser, ab dem 18. Jahrhundert nach englischem Vorbild für Wochenschriften.",
    exampleSentence: "...für die renommiertesten Magazine der Welt..."
  },
  {
    id: "modedesigner",
    word: "Modedesigner",
    lemma: "Modedesigner",
    origin: "Gemischt (Mischform)",
    classification: "Lehnwort",
    originDetails: "Mischkompositum (Hybridwort) aus französisch 'mode' (siehe oben) und englisch 'designer' (vom englischen Verb 'to design', welches über französisch 'dessiner' auf lateinisch 'designare' = bezeichnen zurückgeht).",
    reason: "Linguistische Klassifizierung als Lehnwort bzw. Mischkompositum: Die Flexion des Kompositums wird durch das letzte Glied bestimmt ('Designer'). Dieses n-Suffix verhält sich im deutschen Plural endungslos ('die Designer'), was typisch für eingedeutschte Wörter auf '-er' (Aspirations-Er) ist.",
    observation: "Struktur: Französisierender erster Teil ('Mode-'), anglophoner zweiter Teil ('-designer'). Flexion im Plural ist gleichbleibend (die Modedesigner).",
    interpretation: "Soziolinguistischer Kulturwandel: Ablösung des Begriffs 'Modeschöpfer' in der Nachkriegszeit. Das englische 'Designer' transportiert im deutschen Sprachraum ein höheres Prestige und moderne, professionell-technologische Aspekte.",
    reference: "Duden: Modedesigner als Kompositum seit Mitte des 20. Jahrhunderts.",
    exampleSentence: "...mit ihrem besten Freund, dem Modedesigner Helmut Lang..."
  },
  {
    id: "stilpraegend",
    word: "stilprägend",
    lemma: "Stil",
    origin: "Latein",
    classification: "Vollständig integriert",
    originDetails: "Zurückzuführen auf lateinisch 'stilus' (Griffel, Schreibgerät). Im Zuge des französischen Einflusses auf die Ästhetik im 18. Jahrhundert über 'style' semantisch beeinflusst, orthographisch aber dem lateinischen Skelett angepasst.",
    reason: "Vollständig integriert: Es ist orthographisch angepasst (Eindeutschung 'Stil' ohne 'y' und mit langem 'i'), lautlich integriert ([ʃtiːl] mit pfälzisch/hochdeutschem s-p/s-t Wandel) und extrem produktiv in der Wortbildung.",
    observation: "Phonematische Umwandlung: Der anlautende s-Laut vor t wurde im Deutschen regelhaft zu 'sch' ([ʃ]) palatalisiert. Orthographie vereinfacht auf 'Stil'.",
    interpretation: "Klassisches Begriffserbe: Von der materiellen Schreibfeder zur geistigen Ausprägung des Schreibstils und schließlich zum modischen Gestaltungsmerkmal der Ästhetik im Neunzigerjahre-Kontext.",
    reference: "Kluge: Bereits im Althochdeutschen entlehnt, im 18. Jahrhundert modernisiert durch frz. 'style'.",
    exampleSentence: "...ist stilprägend für die Neunzigerjahre."
  },
  {
    id: "generell",
    word: "Generell",
    lemma: "generell",
    origin: "Französisch",
    classification: "Lehnwort",
    originDetails: "Aus dem französischen 'génériel' oder dem lateinischen 'generalis' (allgemein, die Gattung betreffend) im 18. Jahrhundert entlehnt.",
    reason: "Lehnwort: Anpassung der Vorsilbe und Endung. Das französische Adjektivsuffix '-el' wurde im Deutschen systematisch zu '-ell' verdoppelt und damit dem heimischen Wortakzent unterworfen. Lässt sich wie ein deutsches Erb-Adjektiv flektieren.",
    observation: "Flexion und Schreibung: Großschreibung am Satzanfang. Das Suffix '-ell' signalisiert im Deutschen noch immer ein romanisches Lehnsuffix, ist aber grammatisch voll funktionsfähig.",
    interpretation: "Wissenschafts- und Administrative Sprache: Im Zuge der Etablierung moderner Denkkategorien in der deutschen Aufklärungssprache integriert.",
    reference: "Kluge: Im 18. Jahrhundert entlehnt.",
    exampleSentence: "Generell wird ihre Arbeit immer wieder befruchtet..."
  },
  {
    id: "kreativen",
    word: "Kreativen",
    lemma: "Kreative",
    origin: "Latein",
    classification: "Lehnwort",
    originDetails: "Substantivierung des Adjektivs 'kreativ', welches von lateinisch 'creativus' (schöpferisch) stammt. Das Stammverb ist 'creare' (schaffen, gebären).",
    reason: "Lehnwort: Das Wort hat die typisch deutschen Flektionsmuster der Adjektivnominalisierung angenommen (schwache Dativ-Plural-Endung '-en' nach Präposition 'mit').",
    observation: "Morphologie: Flektiert vollkommen wie ein deutsches Adjektiv ('den Kreativen', 'ein Kreativer'). Lautung voll eingedeutscht ([kre.aˈtiːvən]).",
    interpretation: "Soziolinguistisches Milieu: Aufstieg des Begriffes im Neoliberalismus und der Dienstleistungsgesellschaft ('Kreativwirtschaft'). Das Wort dient heute zur Definition einer soziologischen Schicht ('die Kreativen') und transportiert positive, urbane Attribute.",
    reference: "Duden Herkunftswörterbuch: Adjektiv 'kreativ' im 20. Jahrhundert von englisch 'creative' in der Frequenz massiv verstärkt.",
    exampleSentence: "...durch den Austausch mit anderen Kreativen..."
  },
  {
    id: "aktuell",
    word: "aktuell",
    lemma: "aktuell",
    origin: "Französisch",
    classification: "Vollständig integriert",
    originDetails: "Aus dem französischen 'actuel' (derzeit, wirksam), welches vom spätlateinischen 'actualis' (tätig, wirksam) herrührt.",
    reason: "Wegen seiner vollständigen phonologischen Anpassung und der absoluten Verbreitung im Alltagswortschatz oft nicht mehr als Fremdelement gefühlt (sondern synchron integriert). Orthographisch mit 'k' statt 'c' eingedeutscht.",
    observation: "Strukturell angepasst: Schreibt sich mit 'k' und Doppelkonsonant 'll' am Ende. Nativer Komparationsgrad vorhanden ('aktueller', 'am aktuellsten').",
    interpretation: "Zeitungssprachlicher Modus: Als zeitlicher Orientierungsbegriff unentbehrlich geworden. Der historische Gallizismus ist synchron völlig eingeebnet.",
    reference: "Kluge: Entlehnung im 18. Jahrhundert aus dem Französischen.",
    exampleSentence: "...und ganz aktuell auch in der Landesgalerie Burgenland."
  },
  {
    id: "galerie",
    word: "Landesgalerie",
    lemma: "Galerie",
    origin: "Französisch",
    classification: "Lehnwort",
    originDetails: "Aus dem französischen 'galerie' (Säulengang, Kunstsaal), welches auf italienisch 'galleria' zurückgeht. Das Erstglied 'Landes-' ist germanisch, somit ist 'Landesgalerie' ein Mischkompositum.",
    reason: "Lehnwort: Zwar weist die endbetonte Aussprache [galəˈriː] auf den romanischen Ursprung hin, doch Schreibung, Artikelzuordnung ('die') und Wortbildungspotenzial sind vollständig assimiliert.",
    observation: "Schreibung: Doppel-l aus dem Italienischen wurde im Französischen und Deutschen vereinfacht (ein 'l'). Endbetonung bleibt französisches Erbe.",
    interpretation: "Raumästhetisches Fremdwort: Historischer Bedeutungspfad von einem offenen Säulengang über einen Salon mit Gemälden hin zu staatlichen Kunsthallen oder digitalen Galerien.",
    reference: "Kluge: Im 16. Jahrhundert entlehnt.",
    exampleSentence: "...und ganz aktuell auch in der Landesgalerie Burgenland."
  },
  {
    id: "kilometer",
    word: "Kilometer",
    lemma: "Kilometer",
    origin: "Französisch",
    classification: "Lehnwort",
    originDetails: "Neologismus (künstliche Wortbildung) aus dem Frankreich der Revolution (1795) zur Einführung des Dezimalsystems. Zusammengesetzt aus griechisch 'chilioi' (tausend) und 'metron' (Maß).",
    reason: "Lehnwort: Eindeutschung der Orthographie ('K-' statt französisch/griechisch 'Ch-'), vollständige grammatische Anpassung als deutsches Maskulinum/Neutrum mit deutschem Pluralverhalten.",
    observation: "Lautlich und schriftlich eingedeutscht: 'Chilo-' wurde zu 'Kilo-', die Aussprache folgt deutschen Betonungsgesetzen.",
    interpretation: "Wissenschaftlicher Internationalismus: Ein im Zuge der Standardisierung von Maßen und Gewichten politisch und pädagogisch initiiertes Lehnwort, das fast zeitgleich in alle europäischen Sprachen eindrang.",
    reference: "Duden Herkunftswörterbuch: Maßeinheit, Ende des 18. Jahrhunderts in Frankreich geschaffen und im 19. Jahrhundert in Deutschland gesetzlich verankert.",
    exampleSentence: "...ein paar Kilometer von Jennersdorf entfernt..."
  },
  {
    id: "stationen",
    word: "Stationen",
    lemma: "Station",
    origin: "Latein",
    classification: "Lehnwort",
    originDetails: "Aus dem lateinischen Substantiv 'statio' (Standort, Aufenthalt, Haltestelle), vermutlich über das französische Schwesterwort 'station' im barocken Postwesen vermittelt.",
    reason: "Lehnwort: Es besitzt das typische Fremdsuffix '-tion' ([tsioːn]), ist aber morphologisch ganzheitlich an die schwache deutsche nominale Pluraldeklination auf '-en' gekoppelt.",
    observation: "Phonematik und Flexion: Das lateinische '-tio' wird im Deutschen affriziert zu [tsioːn] gesprochen. Der Plural nimmt das klassisch deutsche Flexiv '-en' an.",
    interpretation: "Kulturhistorischer Sprachkontakt: Vom barocken Post- und Transitwesen (Relaisstation) zu einer existentiellen Lebensecke (Lebensstationen), was das hohe symbolische Metaphernpotenzial von Verkehrsentlehnungen beweist.",
    reference: "Kluge: Im 17. Jahrhundert entlehnt.",
    exampleSentence: "Trotz zahlreicher anderer Stationen..."
  },
  {
    id: "konzentration",
    word: "Konzentration",
    lemma: "Konzentration",
    origin: "Latein",
    classification: "Lehnwort",
    originDetails: "Neulateinisches Abstraktum, gebildet aus dem mittellateinischen Präfix 'con-' (zusammen) und 'centrum' (Mittelpunkt), abgeleitet vom griechischen 'kentron'.",
    reason: "Lehnwort: Schreibung mit 'z' statt lateinisch/französisch 'c' ('Konzentration' statt 'Concentration'/'concentration'). Starke morphologische Integration mit Pluralbildung auf '-en'.",
    observation: "Orthographische Eindeutschung: Der Buchstabe 'C' wurde an zwei Stellen systematisch durch 'K' bzw. 'z' ersetzt, was einen klaren visuellen Indikator für den Lehnstatus liefert.",
    interpretation: "Bildungssprachlicher Einwanderer: Im 18. Jahrhundert in der Naturphilosophie und Psychologie etabliert, um mentale Fokussierung auszudrücken.",
    reference: "Duden Herkunftswörterbuch: Substantivierung zum Verb 'konzentrieren' (18. Jh.).",
    exampleSentence: "...ist es für sie stets ein Ort der Rückkehr, der Konzentration..."
  },
  {
    id: "kontinuierlich",
    word: "kontinuierlich",
    lemma: "kontinuierlich",
    origin: "Französisch",
    classification: "Lehnwort",
    originDetails: "Aus dem französischen Adjektiv 'continuel' (fortlaufend) bzw. dem Verb 'continuer' gebildet, das auf lateinisch 'continuus' (zusammenhängend) basiert.",
    reason: "Linguistisches Hybrid-Lehnwort: Der romanische Verbstamm 'kontinu-' wurde mit dem typischen romanischen Lehnsuffix '-ier' verknüpft, an das wiederum das native deutsche Adjektivsuffix '-lich' angehängt wurde. Diese Kombination ('-ier-lich') markiert eine starke formelle Verdeutschung.",
    observation: "Spezifischer Suffix-Cluster: Stamm 'kontinu-' + Frz.-Deutsches Fugenmorphem 'ier' + deutsches Adjektivierungssuffix 'lich'. Dies macht das Wort extrem geschmeidig für deutsche Satzgefüge.",
    interpretation: "Wissenschaft und Systemik: Ausdruck der zunehmenden Abstraktion der deutschen Schriftsprache der Goethezeit, die romanische Präzisionsstämme mit deutschen Formantien verschmolz.",
    reference: "Kluge: Das zugrundeliegende Verb 'kontinuieren' kam im 17. Jahrhundert auf, 'kontinuierlich' ist eine deutsche Weiterbildung des 18. Jahrhunderts.",
    exampleSentence: "Das Haus wurde kontinuierlich umgebaut..."
  },
  {
    id: "memorabilien",
    word: "Memorabilien",
    lemma: "Memorabilia",
    origin: "Latein",
    classification: "Fremdwort",
    originDetails: "Direkt aus dem lateinischen Neutrum-Plural 'memorabilia' (denkwürdige Dinge) entlehnt. Das Stammwort ist 'memorabilis' (erinnerungswürdig).",
    reason: "Fremdwortcharakter: Behält den lateinischen Stammaufbau fast unverändert bei, ist stark gelehrsam geprägt und transportiert die lateinische Pluralendung, die im Deutschen lediglich um das 'n' der n-Deklination erweitert wurde ('Memorabilien' statt lateinisch 'memorabilia').",
    observation: "Wissenschaftlicher Plural: Die Beibehaltung des Vokalsaums 'ili' vor dem deutschen Pluralmorphem 'en' signalisiert dem Sprecher den gelehrten lateinischen Deklinationscharakter.",
    interpretation: "Sammlerästhetik und Bildungswesen: Semotan nutzt das Wort zur Bezeichnung persönlicher Erinnerungsstücke. Es verweist soziolinguistisch auf einen kultivierten bürgerlichen Lebensstil, der sich gern mit klassischen Gelehrtenbegriffen umgibt.",
    reference: "Duden Fremdwörterbuch: Verzeichnet als Pluraltantum (nur im Plural gebräuchlich) für Erinnerungsstücke.",
    exampleSentence: "...überall finden sich persönliche Memorabilien..."
  },
  {
    id: "ungestylt",
    word: "ungestylt",
    lemma: "stylen",
    origin: "Englisch",
    classification: "Lehnwort",
    originDetails: "Mischbildung (Hybridwort) aus dem englischen Verbstamm 'style' (von engl. 'to style' = gestalten, frisieren). Der Ursprung liegt über altfranzösisch 'estile' schließlich wieder im lateinischen 'stilus'. Die moderne Semantik ist jedoch ein reines Cyber-Zeitalter-Phänomen aus dem Englischen.",
    reason: "Höchster Integrationsgrad (trotz fremder Schreibung im Verbstamm): Es trägt das urdeutsche Negationspräfix 'un-', die deutsche Partizip-Vorsilbe '-ge-' (hier implizit im Komplex verschmolzen, da 'gestylt' das Partizip Perfekt von 'stylen' ist) und das deutsche schwache Suffix '-t' für Adjektive/Partizipien. Es flektiert syntaktisch vollkommen wie ein deutsches Erb-Adjektiv.",
    observation: "Morphologisches Meisterstück deutscher Assimilation: Präfix 'un-' + Partizip I/II 'gestylt' (ge- + style + -t). Trotz des Anglizismus-Stamms verhält sich das Wort rein deutsch.",
    interpretation: "Modernitätsanspruch und Ungezwungenheit: Im Modedesigner-Kontext wird 'ungestylt' ironisch als Lob für Authentizität formuliert. Der Begriff entlarvt die Allgegenwart von Marketing-Englisch, das selbst das Ungeformte nur noch über das verneinte Fremdwort fassen kann.",
    reference: "Duden: Verb 'stylen' im späten 20. Jahrhundert fest integriert; ungestylt als gängiges Partizipialadjektiv verzeichnet.",
    exampleSentence: "...alles ist erfrischend ungestylt."
  },
  {
    id: "prag",
    word: "Prag",
    lemma: "Prag",
    origin: "Keltisch/Andere",
    classification: "Vollständig integriert",
    originDetails: "Toponym tschechischen Ursprungs (tschechisch 'Praha', vermutlich von tschechisch 'prah' = Schwelle, bezogen auf Fluss-Stromschnellen im Fluss Moldau).",
    reason: "Vollständig integriertes Exonym: Über Jahrhunderte des sprachlichen und politischen Kontakts im Böhmischen Bereich fest verankert und lautsprachlich gänzlich einsilbig eingedeutscht. Kein Fremdwortcharakter mehr im modernen Bewusstsein.",
    observation: "Die deutsche Schreibung 'Prag' ersetzt das tschechische 'h' durch 'g', was der historischen deutschen Schreibweise entspricht.",
    interpretation: "Nachbarschaftlicher Sprachkontakt: Historisch intensiver Austausch in Mitteleuropa führte zur Etablierung fester deutscher Namen für slawische Metropolen.",
    reference: "Historisches Ortsnamenlexikon.",
    exampleSentence: "...in unter anderem Prag und New York..."
  },
  {
    id: "new_york",
    word: "New York",
    lemma: "New York",
    origin: "Englisch",
    classification: "Fremdwort",
    originDetails: "Toponym (Eigenname des englischen Sprachraums). Benannt nach dem Herzog von York ('York' geht historisch auf ein keltisch-lateinisches Wort 'Eboracum' zurück).",
    reason: "Als Eigenname (Toponym) ein unverändertes Fremdzitat im deutschen Text. Beibehaltung der englischen Schreibweise (mit getrenntem 'New' statt 'Neu-') und der englischen Lautung.",
    observation: "Fremdsprachiges Zitatwort (Toponym). Unflektiert.",
    interpretation: "Globales Leitbild: Beibehaltung originalsprachlicher Stadtnamen spiegelt die geographische Toleranz und weltweite Reisetätigkeit im 20. und 21. Jahrhundert wider.",
    reference: "Duden.",
    exampleSentence: "...in unter anderem Prag und New York..."
  }
];

export const LINGUISTIC_REPORT_MD = `### 🔍 Linguistischer Befund & Systematische Analyse

Diese wissenschaftliche Untersuchung dokumentiert die sprachlichen Kontaktphänomene im Text über die Fotografin Elfie Semotan. Sie differenziert streng zwischen deskriptiven empirischen Beobachtungen und theoretischen soziolinguistischen Interpretationen.

---

### I. Beobachtungen (Empirischer Befund)

Die linguistische Durchsicht des vorgegebenen Korpus offenbart eine hohe Dichte an Entlehnungen, die deutliche Unterschiede in ihrer phonologischen, graphematischen und morphologischen Integration aufweisen. 

#### 1. Graphematische Befunde (Schriftebene)
* **Vollständige Anpassungen:** Eine Reihe von Wörtern zeigt den Abschluss der graphematischen Eindeutschung. Das klassische Graphem *ph* galloromanischer und gräzistischer Herkunft wurde systematisch durch *f* ersetzt (z. B. **Fotografin**, **fotografieren**). Ebenso wurde das romanische *c* vor dunklen Vokalen durch deutsches *k* ersetzt (z. B. **Kampagne** als Teil von *Werbekampagne*, **Skandal**). Französische Endungen wie *-iel* wurden orthographisch angepasst zu *-ell* (**generell**, **aktuell**).
* **Fremdkörper (Zitatspeicherung):** Einige Wörter verweigern sich jeglicher orthographischer Integration. Sie zeigen Buchstabenkombinationen, die im nativen deutschen System unüblich sind: das *uj* in **Sujets**, das getrennte Schriftbild ohne Bindestrich in **Social Media**, das fehlende zweite *l* in **Model** (zur Abgrenzung vom integrierten *Modell*) sowie die Lautungsgruppierung *ia* im Auslaut von **Editorials**.

#### 2. Morphologische Befunde (Formenebene)
* **Vollständige Paradigmenintegration:** Das Verb **poste** (Stamm *post-*) nimmt perfekt das deutsche schwache Konjugationsparadigma an. Hier ist es im Konjunktiv Präsentis der 3. Person Singular mit der deutschen Konjunktivendung *-e* markiert (*...dass sie nie selbst etwas poste*).
* **Mischmorpheme (Hybridbildungen / Mischkomposita):** Äußerst produktiv verhält sich das Wort **ungestylt**. Während der Stamm *style* englisch ist, sind die präfixalen (*un-*) und suffixalen (*-t*) Begrenzungen rein germanische Flexions- und Wortbildungselemente. Weitere Beispiele sind **Modedesigner** und **Modeschule**, die als Kreuzungen galloromanischer und angloamerikanischer Systemteile dienen.
* **Gelehrtenflexion:** Das Wort **Memorabilien** bewahrt den lateinischen Stammaufbau im Plural (*-abili-*), wird aber im Kasussystem durch das deutsche Flexiv *-en* erweitert, um syntaktisch im Dativ zu harmonieren.

#### 3. Phonologische Befunde (Lautebene)
* **Lautgesetzliche Domestizierung:** Bei **Stil** (in *stilprägend*) hat sich der lateinisch-französische Stamm völlig dem deutschen Lautgesetz des s-t-Wandels ([ʃt]) unterworfen.
* **Fremdlauterhaltung:** **Sujets** ([syˈʒeː]) und **Social Media** ([ˈsoʊʃəl ˈmiːdiə]) bewahren bewusst die Phoneme der Gebersprachen (den stimmhaften postalveolaren Frikativ [ʒ] sowie die englischen Diphthonge).

---

### II. Beispiele nach Herkunftssprachen (Wortlisten)

Im Folgenden werden die identifizierten Entlehnungen systematisch nach Herkunfts- bzw. Vermittlungssprachen katalogisiert:

1. **Französisch (historisch dominant):**
   * *Mode* (in *Modeschule*, *Modedesigner*)
   * *Kampagne* (in *Werbekampagne*)
   * *Sujets* (fachsprachliches Fremdwort)
   * *Porträts* (teilintegriert)
   * *Magazin* (über das Französische vermittelt)
   * *Galerie* (in *Landesgalerie*)
   * *aktuell* (romanisches Suffix *-ell*)
   * *generell* (romanisches Suffix *-ell*)
   * *Kilometer* (metrischer Neologismus des 18. Jh.)

2. **Englisch (modern dominant):**
   * *Social Media* (medienbezogenes Fremdwort)
   * *poste* / *posten* (nach deutschem System konjugiert)
   * *Model* (anglizistischer Grenzfall, semantische Akzentverschiebung)
   * *Editorials* (Zitatform)
   * *Designer* (in *Modedesigner*)
   * *ungestylt* / *stylen* (Hybridform)
   * *New York* (Zitattoponym)

3. **Latein (Bildungssprache):**
   * *Stil* (in *stilprägend*, etymologisch *stilus*)
   * *Kreativen* (nominalisiertes Adjektiv von lat. *creativus*)
   * *Stationen* (lateinisches Erbe)
   * *Konzentration* (klassischer Bildungsbegriff)
   * *Memorabilien* (Pluraltantum wissenschaftlicher Prägung)

4. **Andere & Mischsprachen (Vermittlungsketten):**
   * *Prag* (tschechisch *Praha*, historisches Exonym)
   * *Paris* (keltischer Ursprung)
   * *Magazin* (Wanderwort: Arabisch $\\rightarrow$ Italienisch $\\rightarrow$ Französisch $\\rightarrow$ Deutsch)

---

### III. Interpretation (Soziolinguistische Bewertung)

Der Text spiegelt auf exemplarische Weise die historischen Schichten (Stratifikationen) des fremdsprachlichen Einflusses auf das Deutsche wider:

1. **Die historische Galloromanische Schicht (17.–19. Jahrhundert):**
   Die Wörter **Mode**, **Kampagne**, **Sujets**, **Porträts** und **Galerie** verweisen auf die Epoche des feudalen und bildungsbürgerlichen Kulturextrakts aus Frankreich. Der Austausch findet im feinen intellektuellen, modeorientierten und künstlerischen Milieu statt. Diese Begriffe sind heute so stark im kulturellen System verankert, dass sie teils als Lehnwörter komplett verallgemeinert sind (z. B. *Porträt*, *Mode*), während fachspezifischere Ausdrücke wie **Sujets** ihren Fremdwortcharakter bewusst als soziolinguistisches Distinktionsmerkmal bewahren.

2. **Die moderne Angloamerikanische Schicht (spätes 20. – 21. Jahrhundert):**
   Die neuere Entlehnungswelle ist technisch-digital und globalisiert. **Social Media**, **poste**, **Editorials** und **ungestylt** entspringen dem Jargon der Kreativ- und Medienszene. Das Besondere hierbei ist die Schnelligkeit der morphologischen Integration: Verben wie *posten* und Partizipien wie *ungestylt* werden sofort gebeugt und verhalten sich innerhalb von Jahren grammatikalisch deutscher als Wörter, die jahrhundertelang mühsam orthographisch angepasst wurden. Das zeugt von der ungeheuren morphologischen Dynamik des Gegenwartsdeutschen.

3. **Das Spannungsverhältnis der Sprachregister:**
   Die Koexistenz von lateinischen Termini (**Memorabilien**, **Konzentration**) mit modernem Medienenglisch (**ungestylt**, **Social Media**) erzeugt ein reizvolles soziolinguistisches Spannungsfeld. Es untermalt, dass die beschriebene Person (Elfie Semotan) eine Brücke zwischen der klassischen europäischen Intellektualität (Kippenberger, Paris der 1960er) und der hypermodernen, instantanen Social-Media-Gegenwart schlägt. Das Vokabular ist somit ein direkter Spiegel der biographischen Dynamik des Subjekts.
`;
